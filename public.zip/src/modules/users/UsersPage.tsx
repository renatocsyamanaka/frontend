import React, { useEffect, useMemo, useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { api } from '../../lib/api';
import {
  Avatar,
  Button,
  Form,
  Input,
  Modal,
  Tag,
  Select,
  Upload,
  message,
  Switch,
  Space,
  Tooltip,
  Card,
  List,
  Descriptions,
  Typography,
  InputNumber,
  Spin,
  Row,
  Col,
  Grid,
  Popconfirm,
  Empty,
  Checkbox,
  Divider,
  Image,
  Pagination,
} from 'antd';
import {
  EditOutlined,
  UploadOutlined,
  EnvironmentOutlined,
  HomeOutlined,
  ReloadOutlined,
  SearchOutlined,
  EyeOutlined,
  ApartmentOutlined,
  CheckOutlined,
  CloseOutlined,
  UserAddOutlined,
  ProjectOutlined,
  ShoppingCartOutlined,
  FileDoneOutlined,
  TeamOutlined,
  ClusterOutlined,
  GlobalOutlined,
  IdcardOutlined,
  AppstoreOutlined,
  ToolOutlined,
  BuildOutlined,
  FileTextOutlined,
  BarChartOutlined,
  CarOutlined,
  NotificationOutlined,
  SettingOutlined,
  WhatsAppOutlined,
  LockOutlined,
} from '@ant-design/icons';
import { LocationSelect } from '../shared/LocationSelect';
import UserAddressModal from './UserAddressModal';
import UserMapModal from './UserMapModal';
import { MaskedInput } from 'antd-mask-input';
import { useAuth } from '../auth/AuthProvider';

const { Title, Text } = Typography;
const { useBreakpoint } = Grid;

/** ===== Helpers globais (ABS URL) ===== */
const RAW_API_URL = import.meta.env.VITE_API_URL?.trim();

if (!RAW_API_URL) {
  throw new Error('VITE_API_URL não definida no arquivo .env');
}

const API_URL = RAW_API_URL.replace(/\/+$/, '');

const abs = (url?: string | null) => {
  if (!url) return undefined;
  if (/^https?:\/\//i.test(url)) return url;
  return `${API_URL}/${String(url).replace(/^\/+/, '')}`;
};

const initial = (s?: string | null) => (s?.trim()?.[0]?.toUpperCase() ?? '?');

/** ===== Helpers telefone (MASK dinâmico) ===== */
const formatPhone = (value?: string) => {
  const digits = String(value || '').replace(/\D/g, '').slice(0, 11);

  if (digits.length <= 2) return digits;
  if (digits.length <= 6) return `(${digits.slice(0, 2)}) ${digits.slice(2)}`;
  if (digits.length <= 10) {
    return `(${digits.slice(0, 2)}) ${digits.slice(2, 6)}-${digits.slice(6)}`;
  }

  return `(${digits.slice(0, 2)}) ${digits.slice(2, 7)}-${digits.slice(7)}`;
};

const normalizeRoleName = (s?: string | null) =>
  String(s || '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[_-]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
    .toLowerCase();

const WORKER_ROLE_NAMES = ['tecnico', 'pso', 'ata', 'prp', 'spot'];

const TIPO_ATENDIMENTO_OPTIONS = [
  { value: 'FX', label: 'Fixo' },
  { value: 'VL', label: 'Volante' },
  { value: 'FV', label: 'Fixo e Volante' },
];

const SECTOR_OPTIONS = [
  { value: 'OPERACOES', label: 'Operações' },
  { value: 'LOGISTICA', label: 'Logística' },
  { value: 'SISTEMAS', label: 'Sistemas' },
  { value: 'ATENDIMENTO', label: 'Atendimento' },
];

const DEFAULT_SECTORS = ['OPERACOES'];

const sectorLabelMap = SECTOR_OPTIONS.reduce<Record<string, string>>((acc, item) => {
  acc[item.value] = item.label;
  return acc;
}, {});

const getSectorLabel = (sector?: string | null) =>
  sector ? sectorLabelMap[sector] || sector : '';

const PERMISSION_OPTIONS = [
  { value: 'DASHBOARD_VIEW', label: 'Dashboard' },
  { value: 'PRESTADORES_APROVADOS_VIEW', label: 'Prestadores Aprovados' },
  { value: 'INSTALLATION_PROJECTS_VIEW', label: 'Projetos de Instalação' },
  { value: 'PART_REQUESTS_VIEW', label: 'Pedido de Peças' },
  { value: 'MY_PART_REQUESTS_VIEW', label: 'Meus Pedidos de Peças' },
  { value: 'TECHS_MAP_VIEW', label: 'Mapa Técnicos' },
  { value: 'USERS_VIEW', label: 'Colaboradores' },
  { value: 'ORG_VIEW', label: 'Organograma' },
  { value: 'AUTO_INVENTORY_VIEW', label: 'Auto Inventário' },
  { value: 'AUTO_INVENTORY_ADMIN', label: 'Auto Inventário Admin' },
  { value: 'LOCATIONS_VIEW', label: 'Localidades' },
  { value: 'CLIENTS_VIEW', label: 'Clientes' },
  { value: 'TASKS_VIEW', label: 'Demandas' },
  { value: 'TECH_TYPES_VIEW', label: 'Tipos de Técnicos' },
  { value: 'NEEDS_VIEW', label: 'Requisições Prestadores' },
  { value: 'NEEDS_MAP_VIEW', label: 'Mapa de Requisições' },
  { value: 'ACTIVITY_LOGS_VIEW', label: 'Admin Logs' },
  { value: 'ASSIGNMENTS_VIEW', label: 'Agenda' },
  { value: 'MEDIA_VIEW', label: 'Gerenciador de Imagens' },
  { value: 'OVERTIME_VIEW', label: 'Banco de Horas' },
  { value: 'TIMEOFF_VIEW', label: 'Folgas / Time Off' },
  { value: 'NEWS_VIEW', label: 'Notícias' },
  { value: 'NEWS_ADMIN_VIEW', label: 'Notícias Admin' },
  { value: 'DASHBOARD_ACTIVITY_VIEW', label: 'Planejamento CIA' },
  { value: 'DELIVERY_REPORTS_VIEW', label: 'CTEs' },
  { value: 'WHATSAPP_VIEW', label: 'WhatsApp' },
];
const PERMISSION_ICON_MAP: Record<string, React.ReactNode> = {
  DASHBOARD_VIEW: <HomeOutlined />,
  INSTALLATION_PROJECTS_VIEW: <ProjectOutlined />,
  PART_REQUESTS_VIEW: <ShoppingCartOutlined />,
  MY_PART_REQUESTS_VIEW: <FileDoneOutlined />,
  PRESTADORES_APROVADOS_VIEW: <TeamOutlined />,
  TECHS_MAP_VIEW: <EnvironmentOutlined />,
  USERS_VIEW: <TeamOutlined />,
  ORG_VIEW: <ClusterOutlined />,
  LOCATIONS_VIEW: <GlobalOutlined />,
  CLIENTS_VIEW: <IdcardOutlined />,
  TASKS_VIEW: <AppstoreOutlined />,
  TECH_TYPES_VIEW: <ToolOutlined />,
  MEDIA_VIEW: <AppstoreOutlined />,
  NEEDS_VIEW: <BuildOutlined />,
  NEEDS_MAP_VIEW: <EnvironmentOutlined />,
  ASSIGNMENTS_VIEW: <FileTextOutlined />,
  OVERTIME_VIEW: <BarChartOutlined />,
  TIMEOFF_VIEW: <CarOutlined />,
  ACTIVITY_LOGS_VIEW: <FileTextOutlined />,
  NEWS_VIEW: <NotificationOutlined />,
  WHATSAPP_VIEW: <WhatsAppOutlined />,
  NEWS_ADMIN_VIEW: <SettingOutlined />,
  AUTO_INVENTORY_VIEW: <FileDoneOutlined />,
  AUTO_INVENTORY_ADMIN: <SettingOutlined />,
};

const permissionOptionsWithIcons = PERMISSION_OPTIONS.map((item) => ({
  ...item,
  label: (
    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
      <span style={{ color: '#1F71B8', fontSize: 15 }}>
        {PERMISSION_ICON_MAP[item.value] || <AppstoreOutlined />}
      </span>
      <span>{item.label}</span>
    </div>
  ),
  searchLabel: String(item.label || ''),
}));
const DEFAULT_PERMISSIONS = ['DASHBOARD_VIEW', 'ASSIGNMENTS_VIEW'];

const permissionLabelMap = PERMISSION_OPTIONS.reduce<Record<string, string>>((acc, item) => {
  acc[item.value] = item.label;
  return acc;
}, {});

const getPermissionLabel = (permission?: string | null) =>
  permission ? permissionLabelMap[permission] || permission : '';

const getTipoAtendimentoLabel = (
  value?: 'FX' | 'VL' | 'FV' | null,
  descricao?: string | null
) => {
  if (descricao?.trim()) return descricao;
  if (value === 'FX') return 'Fixo';
  if (value === 'VL') return 'Volante';
  if (value === 'FV') return 'Fixo e Volante';
  return '';
};

type Role = { id: number; name: string; level: number };
type SimpleUser = { id: number; name: string };
type Location = { id: number; name: string };

type User = {
  id: number;
  name: string;
  email?: string | null;
  sex?: 'M' | 'F' | 'O' | null;
  isActive: boolean;
  loginEnabled?: boolean;
  avatarUrl?: string | null;
  role?: Role;
  manager?: SimpleUser | null;
  location?: Location | null;
  estoqueAvancado?: boolean | null;

  cargoDescritivo?: string | null;
  ocultarCargo?: boolean | null;

  addressStreet?: string | null;
  addressNumber?: string | null;
  addressComplement?: string | null;
  addressDistrict?: string | null;
  addressCity?: string | null;
  addressState?: string | null;
  addressZip?: string | null;
  addressCountry?: string | null;
  lat?: number | null;
  lng?: number | null;

  phone?: string | null;
  vendorCode?: string | null;
  serviceAreaCode?: string | null;
  serviceAreaName?: string | null;
  tipoAtendimento?: 'FX' | 'VL' | 'FV' | null;
  tipoAtendimentoDescricao?: string | null;

  permissions?: string[] | null;
  sectors?: string[] | null;
};

type RegistrationRequest = {
  id: number;
  fullName: string;
  email: string;
  sex?: 'M' | 'F' | 'O' | null;
  phone?: string | null;
  avatarUrl?: string | null;
  status: 'PENDING' | 'APPROVED' | 'REJECTED';
  reviewNotes?: string | null;
  createdAt?: string;
  approvedAt?: string | null;
  rejectedAt?: string | null;
  role?: Role | null;
  manager?: SimpleUser | null;
  approvedBy?: SimpleUser | null;
  rejectedBy?: SimpleUser | null;
  roleId?: number;
  managerId?: number | null;
  permissions?: string[] | null;
  sectors?: string[] | null;
  cargoDescritivo?: string | null;
  ocultarCargo?: boolean | null;
};

const BASE_ROLE_OPTIONS = [
  { value: 1, label: 'Técnico' },
  { value: 2, label: 'Analista' },
  { value: 3, label: 'Supervisor' },
  { value: 4, label: 'Coordenador' },
  { value: 5, label: 'Gerente' },
  { value: 6, label: 'Diretor' },
  { value: 7, label: 'Admin' },
  { value: 8, label: 'PSO' },
  { value: 9, label: 'SPOT' },
  { value: 10, label: 'PRP' },
];

const getDisplayRoleLabel = (
  roleName?: string | null,
  cargoDescritivo?: string | null,
  ocultarCargo?: boolean | null
) => {
  if (ocultarCargo) return 'Oculto';
  return cargoDescritivo?.trim() || roleName || '—';
};

const isWorkerRoleByName = (roleName?: string | null) => {
  const r = normalizeRoleName(roleName);
  return WORKER_ROLE_NAMES.includes(r);
};

function OrgCard({
  title,
  person,
  highlight,
  badge,
}: {
  title: string;
  person: any;
  highlight?: boolean;
  badge?: string;
}) {
  return (
    <Card
      size="small"
      style={{
        width: 320,
        maxWidth: '100%',
        borderRadius: 12,
        border: highlight ? '1px solid #93c5fd' : '1px solid #f0f0f0',
        boxShadow: highlight ? '0 6px 18px rgba(59,130,246,0.12)' : undefined,
      }}
      title={
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 8 }}>
          <span>{title}</span>
          {badge ? <Tag color={highlight ? 'blue' : 'default'}>{badge}</Tag> : null}
        </div>
      }
    >
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, minWidth: 0 }}>
        <Avatar src={abs(person?.avatarUrl)} size={44}>
          {initial(person?.nome)}
        </Avatar>
        <div style={{ minWidth: 0 }}>
          <div style={{ fontWeight: 700, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
            {person?.nome || '—'}
          </div>
          <div style={{ color: '#64748b', fontSize: 12 }}>{person?.cargo || '—'}</div>
        </div>
      </div>
    </Card>
  );
}

function OrgMiniCard({ person }: { person: any }) {
  return (
    <Card size="small" style={{ borderRadius: 12 }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, minWidth: 0 }}>
        <Avatar src={abs(person?.avatarUrl)} size={36}>
          {initial(person?.nome)}
        </Avatar>
        <div style={{ minWidth: 0 }}>
          <div style={{ fontWeight: 600, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
            {person?.nome || '—'}
          </div>
          <div style={{ color: '#64748b', fontSize: 12 }}>{person?.cargo || '—'}</div>
        </div>
      </div>
    </Card>
  );
}

const requestStatusTag = (status?: string) => {
  if (status === 'PENDING') return <Tag color="gold">Pendente</Tag>;
  if (status === 'APPROVED') return <Tag color="green">Aprovada</Tag>;
  if (status === 'REJECTED') return <Tag color="red">Reprovada</Tag>;
  return <Tag>{status || '—'}</Tag>;
};
function UserPhotoPreview({
  src,
  name,
  size = 48,
}: {
  src?: string | null;
  name?: string | null;
  size?: number;
}) {
  const imageSrc = abs(src);

  if (!imageSrc) {
    return (
      <Avatar size={size}>
        {initial(name)}
      </Avatar>
    );
  }

  return (
    <Image
      src={imageSrc}
      alt={name || 'Foto do usuário'}
      width={size}
      height={size}
      preview={{
        mask: 'Ver foto',
      }}
      style={{
        width: size,
        height: size,
        objectFit: 'cover',
        borderRadius: '50%',
        cursor: 'pointer',
        border: '1px solid #f0f0f0',
      }}
    />
  );
}
function PermissionChip({ permission }: { permission: string }) {
  return (
    <Tag
      style={{
        padding: '6px 10px',
        borderRadius: 999,
        display: 'inline-flex',
        alignItems: 'center',
        gap: 6,
        borderColor: '#bfdbfe',
        background: '#eff6ff',
        color: '#1d4ed8',
        marginInlineEnd: 0,
      }}
    >
      <span style={{ display: 'flex', alignItems: 'center' }}>
        {PERMISSION_ICON_MAP[permission] || <EditOutlined />}
      </span>
      <span>{getPermissionLabel(permission)}</span>
    </Tag>
  );
}
export function UsersPage() {
  const qc = useQueryClient();
  const screens = useBreakpoint();
  const isMobile = !screens.md;
  const { user: authUser } = useAuth();

  const myLevel = Number(authUser?.role?.level || 0);
  const canCreateWorker = myLevel >= 2;
  const canCreateAnyUser = myLevel >= 5;
  const canEditAnyUser = myLevel >= 5;
  const canReviewRegistrationRequests = myLevel >= 3;
  const [passwordForm] = Form.useForm();
  const [fSearch, setFSearch] = useState<string>('');
  const [fRoles, setFRoles] = useState<number[] | undefined>(undefined);
  const [fActive, setFActive] = useState<'ALL' | 'ACTIVE' | 'INACTIVE'>('ALL');
  const [fManagerId, setFManagerId] = useState<number | undefined>(undefined);
  const [tipoUsuario, setTipoUsuario] = useState<'COLABORADOR' | 'TECNICO'>('COLABORADOR');
  const [mapOpen, setMapOpen] = useState(false);
  const [permissionsOpen, setPermissionsOpen] = useState(false);
  const [permissionsFormType, setPermissionsFormType] = useState<
    'create' | 'edit' | 'approve'
  >('create');
  const [permissionsDraft, setPermissionsDraft] = useState<string[]>([]);

  const getPermissionForm = () => {
    if (permissionsFormType === 'edit') return editForm;
    if (permissionsFormType === 'approve') return editApproveForm;
    return createForm;
  };

  const getFormByType = (type: 'create' | 'edit' | 'approve') => {
    if (type === 'edit') return editForm;
    if (type === 'approve') return editApproveForm;
    return createForm;
  };

  const openPermissionsModal = (type: 'create' | 'edit' | 'approve') => {
    const form = getFormByType(type);
    const current = form.getFieldValue('permissions');

    setPermissionsFormType(type);
    setPermissionsDraft(
      Array.isArray(current) && current.length > 0 ? current : DEFAULT_PERMISSIONS
    );
    setPermissionsOpen(true);
  };
  const { data, isLoading, isFetching, refetch } = useQuery<User[]>({
    queryKey: ['users'],
    queryFn: async () => (await api.get('/users')).data,
  });

  const roleOptions = useMemo(() => {
    const fromData = (data || []).map((u) => u.role).filter(Boolean) as Role[];
    const uniqById = new Map<number, Role>();

    fromData.forEach((r) => {
      if (!uniqById.has(r.id)) uniqById.set(r.id, r);
    });

    const dynamic = Array.from(uniqById.values()).map((r) => ({ value: r.id, label: r.name }));
    const merged = [...dynamic];

    BASE_ROLE_OPTIONS.forEach((base) => {
      if (!merged.find((x) => x.value === base.value)) merged.push(base);
    });

    return merged.sort((a, b) => a.label.localeCompare(b.label, 'pt-BR'));
  }, [data]);

  const isWorkerRoleId = (roleId?: number | null) => {
    const role = roleOptions.find((r) => r.value === roleId);
    return isWorkerRoleByName(String(role?.label || ''));
  };

  const canEditTarget = (u?: User | null) => {
    if (!u) return false;
    if (canEditAnyUser) return true;
    if (myLevel >= 2 && isWorkerRoleByName(u.role?.name)) return true;
    return false;
  };

  const workerRoleOptions = useMemo(() => {
    return roleOptions.filter((r) => {
      const label = normalizeRoleName(String(r.label || ''));
      return WORKER_ROLE_NAMES.includes(label);
    });
  }, [roleOptions]);
  const changeUserPassword = useMutation({
    mutationFn: async ({
      id,
      payload,
    }: {
      id: number;
      payload: {
        newPassword: string;
        confirmNewPassword: string;
      };
    }) => (await api.put(`/users/${id}/change-password`, payload)).data,

    onSuccess: () => {
      message.success('Senha alterada com sucesso');
      passwordForm.resetFields();
    },

    onError: (e: any) => {
      message.error(e?.response?.data?.error || 'Erro ao alterar senha');
    },
  });
  const managerOptions = useMemo(() => {
    const seen = new Set<number>();

    return (data || [])
      .filter((u) => {
        const level = Number(u.role?.level || 0);
        return level >= 3;
      })
      .filter((u) => {
        if (seen.has(u.id)) return false;
        seen.add(u.id);
        return true;
      })
      .map((u) => ({
        value: u.id,
        label: u.name,
      }))
      .sort((a, b) => a.label.localeCompare(b.label, 'pt-BR'));
  }, [data]);

  const filtered = useMemo(() => {
    const list = data || [];

    return list.filter((u) => {
      const isWorker = isWorkerRoleByName(u.role?.name);

      // 👉 AQUI ESTÁ O FILTRO PRINCIPAL
      if (tipoUsuario === 'COLABORADOR' && isWorker) return false;
      if (tipoUsuario === 'TECNICO' && !isWorker) return false;

      if (fSearch) {
        const q = fSearch.toLowerCase();
        const inName = (u.name || '').toLowerCase().includes(q);
        const inEmail = (u.email || '').toLowerCase().includes(q);
        if (!inName && !inEmail) return false;
      }

      if (fRoles && fRoles.length > 0) {
        const rId = u.role?.id;
        if (!rId || !fRoles.includes(rId)) return false;
      }

      if (fActive === 'ACTIVE' && !u.isActive) return false;
      if (fActive === 'INACTIVE' && u.isActive) return false;
      if (fManagerId && u.manager?.id !== fManagerId) return false;

      return true;
    });
  }, [data, tipoUsuario, fSearch, fRoles, fActive, fManagerId]);

  // ================= PAGINAÇÃO =================
  const [currentPage, setCurrentPage] = useState(1);

  const pageSize = isMobile ? 6 : 12;

  const paginatedUsers = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return filtered.slice(start, start + pageSize);
  }, [filtered, currentPage, pageSize]);

  // Resetar página quando filtros mudam
  useEffect(() => {
    setCurrentPage(1);
  }, [fSearch, fRoles, fActive, fManagerId, tipoUsuario]);

  // Evitar página inválida
  useEffect(() => {
    const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize));
    if (currentPage > totalPages) {
      setCurrentPage(totalPages);
    }
  }, [filtered.length, currentPage, pageSize]);

  const [workerOpen, setWorkerOpen] = useState(false);
  const [workerForm] = Form.useForm();
  const [workerAvatarFile, setWorkerAvatarFile] = useState<File | null>(null);
  const workerPhone = Form.useWatch('phone', workerForm);

  const createWorker = useMutation({
    mutationFn: async (payload: any) => (await api.post('/users/workers', payload)).data,
    onSuccess: async (u: User) => {
      if (workerAvatarFile) {
        const fd = new FormData();
        fd.append('file', workerAvatarFile);
        await api.post(`/users/${u.id}/avatar`, fd, {
          headers: { 'Content-Type': 'multipart/form-data' },
        });
        setWorkerAvatarFile(null);
      }

      message.success('Prestador cadastrado');
      await qc.invalidateQueries({ queryKey: ['users'] });
      setWorkerOpen(false);
      workerForm.resetFields();
    },
    onError: (e: any) => {
      console.error('workers ERROR:', e?.response?.data || e);
      message.error(e?.response?.data?.error || 'Erro ao cadastrar prestador');
    },
  });

  const [createOpen, setCreateOpen] = useState(false);
  const [createForm] = Form.useForm();
  const [createAvatarFile, setCreateAvatarFile] = useState<File | null>(null);
  const createPhone = Form.useWatch('phone', createForm);
  const createRoleId = Form.useWatch('roleId', createForm);
  const createSelectedIsWorker = isWorkerRoleId(createRoleId);

  const createUser = useMutation({
    mutationFn: async (payload: any) => (await api.post('/users', payload)).data,
    onSuccess: async (user: User) => {
      const v = createForm.getFieldsValue();
      const hasAddr = v.addressStreet && v.addressCity && v.addressState;

      if (hasAddr) {
        try {
          await api.patch(`/users/${user.id}/address`, {
            addressStreet: v.addressStreet,
            addressNumber: v.addressNumber || '',
            addressComplement: v.addressComplement || '',
            addressDistrict: v.addressDistrict || '',
            addressCity: v.addressCity,
            addressState: v.addressState,
            addressZip: v.addressZip || '',
            addressCountry: v.addressCountry || 'Brasil',
            autoGeocode: false,
            lat: v.lat ?? null,
            lng: v.lng ?? null,
          });
        } catch (e: any) {
          message.warning(e?.response?.data?.error || 'Endereço não foi salvo');
        }
      }

      if (createAvatarFile) {
        const fd = new FormData();
        fd.append('file', createAvatarFile);
        await api.post(`/users/${user.id}/avatar`, fd, {
          headers: { 'Content-Type': 'multipart/form-data' },
        });
        setCreateAvatarFile(null);
      }

      message.success('Usuário criado');
      await qc.invalidateQueries({ queryKey: ['users'] });
      setCreateOpen(false);
      createForm.resetFields();
    },
    onError: (e: any) => message.error(e?.response?.data?.error || 'Erro ao criar'),
  });

  const [editOpen, setEditOpen] = useState(false);
  const [editForm] = Form.useForm();
  const [editing, setEditing] = useState<User | null>(null);
  const [editAvatarFile, setEditAvatarFile] = useState<File | null>(null);
  const editPhone = Form.useWatch('phone', editForm);
  const editRoleId = Form.useWatch('roleId', editForm);
  const editSelectedIsWorker = isWorkerRoleId(editRoleId) || editing?.loginEnabled === false;

  const [addrOpen, setAddrOpen] = useState(false);
  const [addrUser, setAddrUser] = useState<User | null>(null);

  const [viewOpen, setViewOpen] = useState(false);
  const [viewUser, setViewUser] = useState<User | null>(null);

  const [structureOpen, setStructureOpen] = useState(false);
  const [structure, setStructure] = useState<any | null>(null);
  const [loadingStructure, setLoadingStructure] = useState(false);

  async function fetchStructure(userId: number) {
    setLoadingStructure(true);
    try {
      const res = await api.get(`/users/${userId}/structure`);
      setStructure(res.data);
    } catch (e: any) {
      message.error(e?.response?.data?.error || 'Erro ao buscar estrutura');
    } finally {
      setLoadingStructure(false);
    }
  }

  const [geoOpen, setGeoOpen] = useState(false);
  const [geoLoading, setGeoLoading] = useState(false);
  const [geoResults, setGeoResults] = useState<any[]>([]);
  const [geoForForm, setGeoForForm] = useState<'create' | 'worker'>('create');
  const [geoQuery, setGeoQuery] = useState('');

  const searchGeo = async () => {
    if (!geoQuery.trim()) return;
    setGeoLoading(true);
    try {
      const items = (await api.get('/geocode', { params: { q: geoQuery } })).data as any[];
      setGeoResults(items);
    } catch (e: any) {
      message.error(e?.response?.data?.error || 'Falha na busca geográfica');
    } finally {
      setGeoLoading(false);
    }
  };

  const normalizeZip = (value?: string | null) => {
    const digits = String(value || '').replace(/\D/g, '').slice(0, 8);
    if (digits.length <= 5) return digits;
    return `${digits.slice(0, 5)}-${digits.slice(5)}`;
  };

  const applyGeo = (it: any) => {
    const street =
      it.addressStreet ||
      it.street ||
      it.road ||
      it.address?.road ||
      it.address?.pedestrian ||
      it.address?.residential ||
      undefined;

    const district =
      it.addressDistrict ||
      it.district ||
      it.suburb ||
      it.neighbourhood ||
      it.neighborhood ||
      it.address?.suburb ||
      it.address?.neighbourhood ||
      it.address?.neighborhood ||
      undefined;

    const city =
      it.addressCity ||
      it.city ||
      it.town ||
      it.village ||
      it.address?.city ||
      it.address?.town ||
      it.address?.village ||
      it.address?.municipality ||
      undefined;

    const state =
      it.addressState ||
      it.uf ||
      it.state ||
      it.address?.state_code ||
      it.address?.state ||
      undefined;

    const zip =
      normalizeZip(
        it.addressZip ||
        it.zip ||
        it.postcode ||
        it.cep ||
        it.address?.postcode
      ) || undefined;

    const country =
      it.addressCountry ||
      it.country ||
      it.address?.country ||
      'Brasil';

    const patch = {
      addressStreet: street,
      addressDistrict: district,
      addressCity: city,
      addressState: state,
      addressZip: zip,
      addressCountry: country,
      lat: it.lat,
      lng: it.lng,
    };

    if (geoForForm === 'create') createForm.setFieldsValue(patch);
    if (geoForForm === 'worker') workerForm.setFieldsValue(patch);

    setGeoOpen(false);
  };

  const openEditModal = (u: User) => {
    if (!canEditTarget(u)) {
      message.warning('Você não tem permissão para editar este usuário.');
      return;
    }

    setEditing(u);

    editForm.setFieldsValue({
      name: u.name,
      email: u.email || '',
      sex: u.sex || null,
      roleId: u.role?.id,
      managerId: u.manager?.id,
      isActive: u.isActive,
      phone: u.phone || '',
      cargoDescritivo: u.cargoDescritivo || '',
      ocultarCargo: !!u.ocultarCargo,
      permissions: Array.isArray(u.permissions) && u.permissions.length ? u.permissions : DEFAULT_PERMISSIONS,
      sectors: Array.isArray(u.sectors) && u.sectors.length ? u.sectors : DEFAULT_SECTORS,

      vendorCode: isWorkerRoleByName(u.role?.name) ? u.vendorCode || '' : '',
      serviceAreaCode: isWorkerRoleByName(u.role?.name) ? u.serviceAreaCode || '' : '',
      serviceAreaName: isWorkerRoleByName(u.role?.name) ? u.serviceAreaName || '' : '',
      tipoAtendimento: isWorkerRoleByName(u.role?.name) ? u.tipoAtendimento || undefined : undefined,
      estoqueAvancado: isWorkerRoleByName(u.role?.name) ? !!u.estoqueAvancado : false,
    });

    setEditOpen(true);
  };

  const updateUser = useMutation({
    mutationFn: async ({ id, payload }: { id: number; payload: any }) =>
      (await api.patch(`/users/${id}`, payload)).data,
    onSuccess: async (u: User) => {
      if (editAvatarFile) {
        const fd = new FormData();
        fd.append('file', editAvatarFile);
        await api.post(`/users/${u.id}/avatar`, fd, {
          headers: { 'Content-Type': 'multipart/form-data' },
        });
        setEditAvatarFile(null);
      }

      qc.setQueryData<User[]>(['users'], (old) =>
        (old || []).map((item) => (item.id === u.id ? { ...item, ...u } : item))
      );

      setViewUser((prev) => (prev && prev.id === u.id ? { ...prev, ...u } : prev));
      setEditing((prev) => (prev && prev.id === u.id ? { ...prev, ...u } : prev));
      setAddrUser((prev) => (prev && prev.id === u.id ? { ...prev, ...u } : prev));

      message.success('Usuário atualizado');

      await qc.invalidateQueries({ queryKey: ['users'] });

      setEditOpen(false);
      setEditing(null);
    },
    onError: (e: any) => message.error(e?.response?.data?.error || 'Erro ao atualizar'),
  });

  /** =========================
   * SOLICITAÇÕES DE CADASTRO
   * ========================= */
  const [requestsOpen, setRequestsOpen] = useState(false);
  const [requestSearch, setRequestSearch] = useState('');
  const [requestStatusFilter, setRequestStatusFilter] = useState<'ALL' | 'PENDING' | 'APPROVED' | 'REJECTED'>('ALL');

  const [editApproveOpen, setEditApproveOpen] = useState(false);
  const [editApproveForm] = Form.useForm();
  const [editingRequest, setEditingRequest] = useState<RegistrationRequest | null>(null);
  const editApprovePhone = Form.useWatch('phone', editApproveForm);

  const {
    data: registrationRequests,
    isLoading: requestsLoading,
    isFetching: requestsFetching,
    refetch: refetchRequests,
  } = useQuery<RegistrationRequest[]>({
    queryKey: ['user-registration-requests'],
    queryFn: async () => (await api.get('/user-registration-requests')).data,
    enabled: canReviewRegistrationRequests && requestsOpen,
  });

  const filteredRequests = useMemo(() => {
    const list = registrationRequests || [];

    return list.filter((r) => {
      if (requestSearch) {
        const q = requestSearch.toLowerCase();
        const inName = (r.fullName || '').toLowerCase().includes(q);
        const inEmail = (r.email || '').toLowerCase().includes(q);
        if (!inName && !inEmail) return false;
      }

      if (requestStatusFilter !== 'ALL' && r.status !== requestStatusFilter) return false;

      return true;
    });
  }, [registrationRequests, requestSearch, requestStatusFilter]);

  const approveRequest = useMutation({
    mutationFn: async (id: number) =>
      (await api.put(`/user-registration-requests/${id}/approve`, {
        permissions: DEFAULT_PERMISSIONS,
        sectors: DEFAULT_SECTORS,
      })).data,
    onSuccess: async () => {
      message.success('Solicitação aprovada com sucesso');
      await qc.invalidateQueries({ queryKey: ['user-registration-requests'] });
      await qc.invalidateQueries({ queryKey: ['users'] });
    },
    onError: (e: any) => {
      message.error(e?.response?.data?.error || 'Erro ao aprovar solicitação');
    },
  });

  const rejectRequest = useMutation({
    mutationFn: async ({ id, reviewNotes }: { id: number; reviewNotes?: string | null }) =>
      (await api.put(`/user-registration-requests/${id}/reject`, { reviewNotes: reviewNotes || null })).data,
    onSuccess: async () => {
      message.success('Solicitação reprovada');
      await qc.invalidateQueries({ queryKey: ['user-registration-requests'] });
    },
    onError: (e: any) => {
      message.error(e?.response?.data?.error || 'Erro ao reprovar solicitação');
    },
  });

  const approveRequestWithEdit = useMutation({
    mutationFn: async ({ id, payload }: { id: number; payload: any }) =>
      (await api.put(`/user-registration-requests/${id}/approve`, payload)).data,
    onSuccess: async () => {
      message.success('Solicitação editada e aprovada com sucesso');
      await qc.invalidateQueries({ queryKey: ['user-registration-requests'] });
      await qc.invalidateQueries({ queryKey: ['users'] });
      setEditApproveOpen(false);
      setEditingRequest(null);
      editApproveForm.resetFields();
    },
    onError: (e: any) => {
      message.error(e?.response?.data?.error || 'Erro ao editar/aprovar solicitação');
    },
  });

  const openEditApproveModal = (req: RegistrationRequest) => {
    setEditingRequest(req);
    editApproveForm.setFieldsValue({
      fullName: req.fullName,
      email: req.email,
      sex: req.sex || null,
      roleId: req.role?.id || req.roleId || undefined,
      managerId: req.manager?.id || req.managerId || undefined,
      phone: req.phone || '',
      reviewNotes: req.reviewNotes || '',
      cargoDescritivo: req.cargoDescritivo || '',
      ocultarCargo: !!req.ocultarCargo,
      permissions:
        Array.isArray(req.permissions) && req.permissions.length
          ? req.permissions
          : DEFAULT_PERMISSIONS,
      sectors:
        Array.isArray(req.sectors) && req.sectors.length
          ? req.sectors
          : DEFAULT_SECTORS,
    });
    setEditApproveOpen(true);
  };

  const viewUserIsWorker = isWorkerRoleByName(viewUser?.role?.name);

  return (
      <div
        style={{
          display: 'grid',
          gap: 16,
          width: '100%',
          maxWidth: '100%',
          overflowX: 'hidden',
        }}
      >
    <div
      style={{
        display: 'grid',
        gap: 16,
        width: '100%',
        maxWidth: '100%',
        overflowX: 'clip',
      }}
    >
        <Card
          style={{
            borderRadius: 24,
            border: '1px solid #e5e7eb',
            boxShadow: '0 8px 24px rgba(15, 23, 42, 0.06)',
            width: '100%',
            maxWidth: '100%',
            overflow: 'hidden',
          }}
          styles={{
            body: {
              padding: isMobile ? 16 : 24,
            },
          }}
        >
        <Row
          gutter={[16, 16]}
          align="middle"
          justify="space-between"
          style={{ width: '100%', margin: 0 }}
        >
          <Col xs={24} md={14} style={{ minWidth: 0 }}>
            <div
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: 16,
                minWidth: 0,
              }}
            >
              <div
                style={{
                  width: 52,
                  height: 52,
                  borderRadius: 16,
                  background: 'linear-gradient(135deg, #1677ff 0%, #4096ff 100%)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  color: '#fff',
                  fontSize: 22,
                  flexShrink: 0,
                  boxShadow: '0 8px 18px rgba(22,119,255,0.22)',
                }}
              >
                <TeamOutlined />
              </div>

              <div style={{ minWidth: 0, flex: 1 }}>
                <div
                  style={{
                    fontSize: isMobile ? 22 : 28,
                    fontWeight: 700,
                    color: '#0f172a',
                    lineHeight: 1.1,
                  }}
                >
                  {tipoUsuario === 'COLABORADOR' ? 'Colaboradores' : 'Técnicos'}
                </div>

                <div
                  style={{
                    color: '#64748b',
                    fontSize: 14,
                    marginTop: 4,
                    lineHeight: 1.45,
                  }}
                >
                  {tipoUsuario === 'COLABORADOR'
                    ? 'Gerencie os colaboradores internos e acompanhe seus dados de acesso.'
                    : 'Gerencie os técnicos e prestadores cadastrados no sistema.'}
                </div>
              </div>
            </div>
          </Col>

          <Col xs={24} md="auto" style={{ minWidth: 0 }}>
            <Space
              wrap
              size={[8, 8]}
              style={{
                width: '100%',
                justifyContent: isMobile ? 'flex-start' : 'flex-end',
              }}
            >
              <Button
                icon={<ReloadOutlined />}
                loading={isFetching}
                onClick={() => refetch()}
              >
                Atualizar
              </Button>

              {canReviewRegistrationRequests && tipoUsuario === 'COLABORADOR' && (
                <Button
                  icon={<UserAddOutlined />}
                  onClick={() => {
                    setRequestsOpen(true);
                    refetchRequests();
                  }}
                >
                  Solicitações de cadastro
                </Button>
              )}

              {canCreateAnyUser && tipoUsuario === 'COLABORADOR' && (
                <Button
                  type="primary"
                  onClick={() => setCreateOpen(true)}
                >
                  Novo usuário
                </Button>
              )}

              {canCreateWorker && tipoUsuario === 'TECNICO' && (
                <Button
                  type="primary"
                  onClick={() => setWorkerOpen(true)}
                >
                  Cadastrar prestador
                </Button>
              )}
            </Space>
          </Col>
        </Row>

        <div style={{ marginTop: 20 }}>
          <div
            style={{
              display: 'flex',
              gap: 8,
              flexWrap: 'wrap',
              width: '100%',
            }}
          >
            <Button
              type={tipoUsuario === 'COLABORADOR' ? 'primary' : 'default'}
              onClick={() => setTipoUsuario('COLABORADOR')}
              style={{
                borderRadius: 12,
                fontWeight: 600,
                minWidth: isMobile ? undefined : 150,
                flex: isMobile ? 1 : undefined,
              }}
            >
              Colaboradores
            </Button>

            <Button
              type={tipoUsuario === 'TECNICO' ? 'primary' : 'default'}
              onClick={() => setTipoUsuario('TECNICO')}
              style={{
                borderRadius: 12,
                fontWeight: 600,
                minWidth: isMobile ? undefined : 150,
                flex: isMobile ? 1 : undefined,
              }}
            >
              Técnicos
            </Button>
          </div>
        </div>
      </Card>

      <Card
        size="small"
        style={{
          borderRadius: 18,
          border: '1px solid #eef2f7',
          boxShadow: '0 6px 18px rgba(15, 23, 42, 0.04)',
          overflow: 'hidden',
        }}
        styles={{ body: { padding: 16 } }}
      >
        <Row gutter={[12, 12]} style={{ margin: 0 }}>
          <Col xs={24} md={8} lg={7}>
            <Input
              allowClear
              prefix={<SearchOutlined />}
              placeholder="Buscar por nome ou e-mail"
              value={fSearch}
              onChange={(e) => setFSearch(e.target.value)}
            />
          </Col>

          <Col xs={24} md={8} lg={7}>
            <Select
              mode="multiple"
              allowClear
              placeholder="Filtrar por cargo"
              value={fRoles}
              onChange={(vals) => setFRoles(vals as number[] | undefined)}
              options={roleOptions}
              optionFilterProp="label"
              style={{ width: '100%' }}
              maxTagCount="responsive"
            />
          </Col>

          <Col xs={24} md={8} lg={4}>
            <Select
              value={fActive}
              onChange={(v) => setFActive(v)}
              style={{ width: '100%' }}
              options={[
                { value: 'ALL', label: 'Todos' },
                { value: 'ACTIVE', label: 'Ativos' },
                { value: 'INACTIVE', label: 'Inativos' },
              ]}
            />
          </Col>

          <Col xs={24} md={12} lg={4}>
            <Select
              allowClear
              showSearch
              placeholder="Filtrar por gestor"
              value={fManagerId}
              onChange={(v) => setFManagerId(v)}
              options={managerOptions}
              optionFilterProp="label"
              filterOption={(input, option) =>
                String(option?.label || '').toLowerCase().includes(input.toLowerCase())
              }
              style={{ width: '100%' }}
            />
          </Col>

          <Col xs={24} md={12} lg={2}>
            <Button
              block
              onClick={() => {
                setFSearch('');
                setFRoles(undefined);
                setFActive('ALL');
                setFManagerId(undefined);
              }}
            >
              Limpar
            </Button>
          </Col>
        </Row>
      </Card>

      {isLoading ? (
        <Card
          style={{
            borderRadius: 18,
            textAlign: 'center',
            padding: 32,
          }}
        >
          <Spin />
        </Card>
      ) : filtered.length === 0 ? (
        <Card
          style={{
            borderRadius: 18,
          }}
        >
          <Empty description="Nenhum usuário encontrado" />
        </Card>
      ) : (
        <>
          <Row gutter={[16, 16]} style={{ margin: 0 }}>
           {paginatedUsers.map((u) => {
              const atendimentoLabel = getTipoAtendimentoLabel(
                u.tipoAtendimento,
                u.tipoAtendimentoDescricao
              );
              const userIsWorker = isWorkerRoleByName(u.role?.name);

              return (
                <Col xs={24} sm={12} lg={8} xl={6} key={u.id}>
                  <Card
                    hoverable
                    style={{
                      borderRadius: 20,
                      border: '1px solid #eaeef5',
                      boxShadow: '0 8px 24px rgba(15, 23, 42, 0.05)',
                      height: '100%',
                    }}
                    styles={{
                      body: {
                        padding: 18,
                        height: '100%',
                        display: 'flex',
                        flexDirection: 'column',
                      },
                    }}
                  >
                    <div
                      style={{
                        display: 'flex',
                        justifyContent: 'flex-end',
                        gap: 6,
                        flexWrap: 'wrap',
                        minHeight: 28,
                        marginBottom: 14,
                      }}
                    >
                      {u.isActive ? <Tag color="green">Ativo</Tag> : <Tag>Inativo</Tag>}
                      {userIsWorker && !!u.estoqueAvancado && (
                        <Tag color="purple">Estoque avançado</Tag>
                      )}
                      {userIsWorker && !!atendimentoLabel && (
                        <Tag color="cyan">{atendimentoLabel}</Tag>
                      )}
                      {u.ocultarCargo && <Tag color="default">Cargo oculto</Tag>}
                    </div>

                    <div
                      style={{
                        display: 'flex',
                        gap: 14,
                        alignItems: 'flex-start',
                        minWidth: 0,
                        flex: 1,
                      }}
                    >
                      <Avatar
                        src={abs(u.avatarUrl)}
                        size={58}
                        style={{
                          flexShrink: 0,
                          background: '#dbeafe',
                          color: '#1d4ed8',
                          fontWeight: 700,
                        }}
                      >
                        {u.name?.[0]}
                      </Avatar>

                      <div style={{ flex: 1, minWidth: 0 }}>
                        <Title
                          level={5}
                          style={{
                            margin: 0,
                            lineHeight: 1.25,
                            fontSize: 18,
                            wordBreak: 'break-word',
                          }}
                        >
                          {u.name}
                        </Title>

                        <div
                          style={{
                            color: '#475569',
                            marginTop: 6,
                            fontWeight: 500,
                          }}
                        >
                          {getDisplayRoleLabel(u.role?.name, u.cargoDescritivo, u.ocultarCargo)}
                        </div>

                        <div style={{ color: '#94a3b8', marginTop: 8 }}>
                          Gestor: {u.manager?.name || '-'}
                        </div>

                        {Array.isArray(u.sectors) && u.sectors.length > 0 && (
                          <div style={{ color: '#94a3b8', marginTop: 4 }}>
                            Setor: {u.sectors.map(getSectorLabel).join(', ')}
                          </div>
                        )}

                        {userIsWorker && !!atendimentoLabel && (
                          <div style={{ color: '#94a3b8', marginTop: 4 }}>
                            Atendimento: {atendimentoLabel}
                          </div>
                        )}
                      </div>
                    </div>

                    <div
                      style={{
                        display: 'grid',
                        gridTemplateColumns: isMobile ? '1fr' : '1fr 1fr',
                        gap: 8,
                        marginTop: 18,
                      }}
                    >
                      <Button
                        icon={<EyeOutlined />}
                        onClick={() => {
                          setViewUser(u);
                          setViewOpen(true);
                        }}
                      >
                        Informações
                      </Button>

                      <Button
                        icon={<ApartmentOutlined />}
                        onClick={() => {
                          setViewUser(u);
                          setStructureOpen(true);
                          fetchStructure(u.id);
                        }}
                      >
                        Estrutura
                      </Button>
                    </div>
                  </Card>
                </Col>
              );
            })}
          </Row>

          <div
            style={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              gap: 12,
              flexWrap: 'wrap',
              marginTop: 20,
            }}
          >
            <Text type="secondary">
              Total: {filtered.length} {filtered.length === 1 ? 'registro' : 'registros'}
            </Text>

            <Pagination
              current={currentPage}
              pageSize={pageSize}
              total={filtered.length}
              onChange={(page) => setCurrentPage(page)}
              showSizeChanger={false}
            />
          </div>
        </>
      )}
    </div>


      <Modal
        title={
          <div
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: 16,
              minWidth: 0,
            }}
          >
            <UserPhotoPreview
              src={viewUser?.avatarUrl}
              name={viewUser?.name}
              size={72}
            />

            <div style={{ minWidth: 0 }}>
              <div
                style={{
                  fontWeight: 700,
                  fontSize: 28,
                  lineHeight: 1.15,
                  color: '#0f172a',
                }}
              >
                {viewUser?.name}
              </div>

              <div
                style={{
                  color: '#64748b',
                  fontSize: 15,
                  marginTop: 4,
                }}
              >
                {getDisplayRoleLabel(
                  viewUser?.role?.name,
                  viewUser?.cargoDescritivo,
                  viewUser?.ocultarCargo
                )}
              </div>

              <Space wrap size={[8, 8]} style={{ marginTop: 10 }}>
                <Tag color={viewUser?.isActive ? 'green' : 'default'}>
                  {viewUser?.isActive ? 'Ativo' : 'Inativo'}
                </Tag>

                {viewUser?.ocultarCargo && <Tag color="default">Cargo oculto</Tag>}
                {!!viewUser?.estoqueAvancado && <Tag color="purple">Estoque avançado</Tag>}
              </Space>
            </div>
          </div>
        }
        open={viewOpen}
        onCancel={() => {
          setViewOpen(false);
          setViewUser(null);
        }}
        footer={
          <Space wrap style={{ justifyContent: 'flex-end', width: '100%' }}>
            <Tooltip title={viewUser?.lat && viewUser?.lng ? 'Ver no mapa' : 'Sem coordenadas'}>
              <Button
                icon={<EnvironmentOutlined />}
                disabled={!(Number.isFinite(Number(viewUser?.lat)) && Number.isFinite(Number(viewUser?.lng)))}
                onClick={() => setMapOpen(true)}
              >
                Ver no mapa
              </Button>
            </Tooltip>

            {canEditTarget(viewUser) && (
              <Button
                icon={<HomeOutlined />}
                onClick={() => {
                  if (!viewUser) return;
                  setAddrUser(viewUser);
                  setAddrOpen(true);
                }}
              >
                Endereço
              </Button>
            )}

            {canEditTarget(viewUser) && (
              <Button
                type="primary"
                icon={<EditOutlined />}
                onClick={() => {
                  if (!viewUser) return;
                  openEditModal(viewUser);
                }}
              >
                Editar
              </Button>
            )}

            <Button
              onClick={() => {
                setViewOpen(false);
                setViewUser(null);
              }}
            >
              Fechar
            </Button>
          </Space>
        }
        destroyOnHidden
        width={isMobile ? '100%' : 1240}
        centered
        style={isMobile ? { top: 0, padding: 0 } : undefined}
        styles={{
          body: {
            paddingTop: 12,
            maxHeight: isMobile ? 'calc(100vh - 120px)' : '78vh',
            overflowY: 'auto',
            overflowX: 'clip',
          },
        }}
      >
        {viewUser && (
          <Row gutter={[16, 16]} align="stretch">
            <Col xs={24} xl={14}>
              <Space direction="vertical" size={16} style={{ width: '100%' }}>
                <Card
                  size="small"
                  title="Profissional"
                  style={{ borderRadius: 14 }}
                  styles={{ body: { paddingBottom: 8 } }}
                >
                  <Descriptions column={1} size="small">
                    <Descriptions.Item label="Cargo descritivo">
                      {viewUser.ocultarCargo ? 'Oculto' : viewUser.cargoDescritivo || '—'}
                    </Descriptions.Item>
                    <Descriptions.Item label="Gestor">{viewUser.manager?.name || '—'}</Descriptions.Item>
                    <Descriptions.Item label="Status">{viewUser.isActive ? 'Ativo' : 'Inativo'}</Descriptions.Item>
                    <Descriptions.Item label="Login">
                      {viewUser.loginEnabled === false ? 'Sem login' : 'Com login'}
                    </Descriptions.Item>
                    {viewUserIsWorker && (
                      <Descriptions.Item label="Estoque avançado">
                        {viewUser.estoqueAvancado ? 'Sim' : 'Não'}
                      </Descriptions.Item>
                    )}
                    <Descriptions.Item label="Setor">
                      {Array.isArray(viewUser.sectors) && viewUser.sectors.length > 0
                        ? viewUser.sectors.map(getSectorLabel).join(', ')
                        : '—'}
                    </Descriptions.Item>
                  </Descriptions>
                </Card>

                <Card
                  size="small"
                  title="Contato"
                  style={{ borderRadius: 14 }}
                  styles={{ body: { paddingBottom: 8 } }}
                >
                  <Descriptions column={1} size="small">
                    <Descriptions.Item label="E-mail">{viewUser.email || '—'}</Descriptions.Item>
                    <Descriptions.Item label="Telefone">{viewUser.phone || '—'}</Descriptions.Item>
                  </Descriptions>
                </Card>

                {viewUserIsWorker && (
                  <Card
                    size="small"
                    title="Área de atendimento"
                    style={{ borderRadius: 14 }}
                    styles={{ body: { paddingBottom: 8 } }}
                  >
                    <Descriptions column={1} size="small">
                      <Descriptions.Item label="Código fornecedor">{viewUser.vendorCode || '—'}</Descriptions.Item>
                      <Descriptions.Item label="Código da área">{viewUser.serviceAreaCode || '—'}</Descriptions.Item>
                      <Descriptions.Item label="Nome da área">{viewUser.serviceAreaName || '—'}</Descriptions.Item>
                      <Descriptions.Item label="Tipo de atendimento">
                        {getTipoAtendimentoLabel(viewUser.tipoAtendimento, viewUser.tipoAtendimentoDescricao) || '—'}
                      </Descriptions.Item>
                    </Descriptions>
                  </Card>
                )}
              </Space>
            </Col>

            <Col xs={24} xl={10}>
              <Space direction="vertical" size={16} style={{ width: '100%' }}>
                <Card
                  size="small"
                  title="Permissões"
                  style={{ borderRadius: 14 }}
                  styles={{ body: { paddingBottom: 8 } }}
                >
                  {Array.isArray(viewUser.permissions) && viewUser.permissions.length > 0 ? (
                    <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                      {viewUser.permissions.map((permission) => (
                        <PermissionChip key={permission} permission={permission} />
                      ))}
                    </div>
                  ) : (
                    <Text type="secondary">Sem permissões definidas</Text>
                  )}
                </Card>

                <Card
                  size="small"
                  title="Endereço"
                  style={{ borderRadius: 14 }}
                  styles={{ body: { paddingBottom: 8 } }}
                >
                  <Descriptions column={1} size="small">
                    <Descriptions.Item label="Logradouro">
                      {viewUser.addressStreet || '—'} {viewUser.addressNumber || ''}
                    </Descriptions.Item>
                    <Descriptions.Item label="Complemento">
                      {viewUser.addressComplement || '—'}
                    </Descriptions.Item>
                    <Descriptions.Item label="Bairro">
                      {viewUser.addressDistrict || '—'}
                    </Descriptions.Item>
                    <Descriptions.Item label="Cidade/UF">
                      {viewUser.addressCity || '—'}
                      {viewUser.addressState ? ` / ${viewUser.addressState}` : ''}
                    </Descriptions.Item>
                    <Descriptions.Item label="CEP">{viewUser.addressZip || '—'}</Descriptions.Item>
                    <Descriptions.Item label="País">{viewUser.addressCountry || 'Brasil'}</Descriptions.Item>
                    <Descriptions.Item label="Coordenadas">
                      {viewUser.lat && viewUser.lng ? (
                        <Tag
                          color="green"
                          style={{
                            maxWidth: '100%',
                            display: 'inline-block',
                            whiteSpace: 'normal',
                            overflowWrap: 'anywhere',
                            wordBreak: 'break-word',
                          }}
                        >
                          {viewUser.lat}, {viewUser.lng}
                        </Tag>
                      ) : (
                        <Tag>Sem coordenadas</Tag>
                      )}
                    </Descriptions.Item>
                  </Descriptions>
                </Card>
              </Space>
            </Col>
          </Row>
        )}
      </Modal>

      <UserMapModal
        open={mapOpen}
        onClose={() => setMapOpen(false)}
        title={`Mapa — ${viewUser?.name || ''}`}
        lat={viewUser?.lat}
        lng={viewUser?.lng}
        addressLabel={[
          viewUser?.addressStreet,
          viewUser?.addressNumber,
          viewUser?.addressDistrict,
          viewUser?.addressCity,
          viewUser?.addressState,
          viewUser?.addressZip,
        ]
          .filter(Boolean)
          .join(', ')}
      />

      {canCreateAnyUser && (
      <Modal
        title="Novo colaborador"
        open={createOpen}
        onCancel={() => {
          setCreateOpen(false);
          setCreateAvatarFile(null);
          createForm.resetFields();
        }}
        onOk={() => createForm.submit()}
        destroyOnHidden
        width={isMobile ? '100%' : 1380}
        centered
        style={isMobile ? { top: 0, padding: 0 } : undefined}
        styles={{
          body: {
            paddingTop: 12,
            maxHeight: isMobile ? 'calc(100vh - 110px)' : '78vh',
            overflowY: 'auto',
            overflowX: 'hidden',
          },
        }}
      >
        <Form
          layout="vertical"
          form={createForm}
          initialValues={{
            permissions: DEFAULT_PERMISSIONS,
            sectors: DEFAULT_SECTORS,
            ocultarCargo: false,
            estoqueAvancado: false,
            addressCountry: 'Brasil',
          }}
          onFinish={(v) => {
            const isWorker = isWorkerRoleId(v.roleId);

            const payload = {
              name: v.name,
              email: v.email,
              password: v.password,
              sex: v.sex,
              roleId: v.roleId,
              managerId: v.managerId ?? null,
              locationId: v.locationId ?? null,
              phone: v.phone || null,
              cargoDescritivo: v.cargoDescritivo?.trim() || null,
              ocultarCargo: !!v.ocultarCargo,
              vendorCode: isWorker ? v.vendorCode || null : null,
              serviceAreaCode: isWorker ? v.serviceAreaCode || null : null,
              serviceAreaName: isWorker ? v.serviceAreaName || null : null,
              tipoAtendimento: isWorker ? v.tipoAtendimento || null : null,
              estoqueAvancado: isWorker ? !!v.estoqueAvancado : false,
              sectors:
                Array.isArray(v.sectors) && v.sectors.length
                  ? v.sectors
                  : DEFAULT_SECTORS,
              permissions:
                Array.isArray(v.permissions) && v.permissions.length
                  ? v.permissions
                  : DEFAULT_PERMISSIONS,
              addressStreet: v.addressStreet || null,
              addressNumber: v.addressNumber || null,
              addressComplement: v.addressComplement || null,
              addressDistrict: v.addressDistrict || null,
              addressCity: v.addressCity || null,
              addressState: v.addressState || null,
              addressZip: v.addressZip || null,
              addressCountry: v.addressCountry || 'Brasil',
              lat: v.lat ?? null,
              lng: v.lng ?? null,
            };

            createUser.mutate(payload);
          }}
        >
          <Row gutter={[16, 16]} align="stretch">
            <Col xs={24} xl={13}>
              <Card
                size="small"
                title="Dados do colaborador"
                style={{ borderRadius: 14, height: '100%' }}
                styles={{ body: { paddingBottom: 8 } }}
              >
                <Row gutter={[12, 12]}>
                  <Col xs={24}>
                    <div
                      style={{
                        display: 'flex',
                        gap: 16,
                        alignItems: 'center',
                        padding: 12,
                        border: '1px dashed #d9d9d9',
                        borderRadius: 12,
                        background: '#fafafa',
                      }}
                    >
                      <Upload
                        accept="image/*"
                        maxCount={1}
                        beforeUpload={(file) => {
                          setCreateAvatarFile(file);
                          return false;
                        }}
                        onRemove={() => setCreateAvatarFile(null)}
                        showUploadList={false}
                      >
                        <div
                          style={{
                            width: 88,
                            height: 88,
                            borderRadius: 14,
                            overflow: 'hidden',
                            border: '1px solid #d9d9d9',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            background: '#fff',
                            cursor: 'pointer',
                            flexShrink: 0,
                          }}
                        >
                          {createAvatarFile ? (
                            <img
                              src={URL.createObjectURL(createAvatarFile)}
                              alt="preview"
                              style={{ width: '100%', height: '100%', objectFit: 'cover' }}
                            />
                          ) : (
                            <UploadOutlined style={{ fontSize: 24, color: '#8c8c8c' }} />
                          )}
                        </div>
                      </Upload>

                      <div style={{ flex: 1 }}>
                        <div style={{ fontWeight: 600, marginBottom: 4 }}>
                          Foto do colaborador
                        </div>
                        <div style={{ color: '#8c8c8c', fontSize: 13, marginBottom: 10 }}>
                          Adicione uma foto para identificação do colaborador.
                        </div>

                        <Space wrap>
                          <Upload
                            accept="image/*"
                            maxCount={1}
                            beforeUpload={(file) => {
                              setCreateAvatarFile(file);
                              return false;
                            }}
                            onRemove={() => setCreateAvatarFile(null)}
                            showUploadList={false}
                          >
                            <Button icon={<UploadOutlined />}>Selecionar foto</Button>
                          </Upload>

                          {createAvatarFile && (
                            <Button onClick={() => setCreateAvatarFile(null)}>
                              Remover
                            </Button>
                          )}
                        </Space>
                      </div>
                    </div>
                  </Col>

                  <Col xs={24} md={14}>
                    <Form.Item name="name" label="Nome" rules={[{ required: true, message: 'Informe o nome' }]}>
                      <Input placeholder="Nome do colaborador" />
                    </Form.Item>
                  </Col>

                  <Col xs={24} md={10}>
                    <Form.Item name="phone" label="Telefone">
                      <Input
                        placeholder="(11) 99999-9999"
                        maxLength={15}
                        value={createForm.getFieldValue('phone')}
                        onChange={(e) => {
                          createForm.setFieldValue('phone', formatPhone(e.target.value));
                        }}
                      />
                    </Form.Item>
                  </Col>

                  <Col xs={24} md={14}>
                    <Form.Item
                      name="email"
                      label="E-mail"
                      rules={[{ required: true, type: 'email', message: 'Informe um e-mail válido' }]}
                    >
                      <Input placeholder="email@empresa.com" />
                    </Form.Item>
                  </Col>

                  <Col xs={24} md={10}>
                    <Form.Item
                      name="password"
                      label="Senha"
                      rules={[{ required: true, min: 6, message: 'Informe uma senha com no mínimo 6 caracteres' }]}
                    >
                      <Input.Password placeholder="Digite a senha" />
                    </Form.Item>
                  </Col>

                  <Col xs={24} md={8}>
                    <Form.Item name="sex" label="Sexo">
                      <Select
                        allowClear
                        placeholder="Selecione"
                        options={[
                          { value: 'M', label: 'Masculino' },
                          { value: 'F', label: 'Feminino' },
                          { value: 'O', label: 'Outro' },
                        ]}
                      />
                    </Form.Item>
                  </Col>

                  <Col xs={24} md={8}>
                    <Form.Item name="roleId" label="Cargo" rules={[{ required: true, message: 'Selecione o cargo' }]}>
                      <Select
                        placeholder="Selecione"
                        options={roleOptions}
                        optionFilterProp="label"
                      />
                    </Form.Item>
                  </Col>

                  <Col xs={24} md={8}>
                    <Form.Item name="cargoDescritivo" label="Cargo descritivo">
                      <Input
                        placeholder="Ex.: Coordenador de Dados"
                        maxLength={150}
                      />
                    </Form.Item>
                  </Col>

                  <Col xs={24} md={12}>
                    <Form.Item name="managerId" label="Gestor">
                      <Select
                        allowClear
                        showSearch
                        placeholder="Selecione o gestor"
                        options={managerOptions}
                        optionFilterProp="label"
                        filterOption={(input, option) =>
                          String(option?.label || '').toLowerCase().includes(input.toLowerCase())
                        }
                      />
                    </Form.Item>
                  </Col>

                  <Col xs={24}>
                    <Form.Item
                      label="Abas / Permissões de acesso"
                      tooltip="Selecione as páginas que esse usuário poderá acessar"
                    >
                      <Button
                        block
                        onClick={() => openPermissionsModal('create')}
                      >
                        Gerenciar permissões
                      </Button>

                      <div style={{ marginTop: 8, color: '#64748b', fontSize: 13 }}>
                        {((createForm.getFieldValue('permissions') as string[]) || []).length
                          ? `${((createForm.getFieldValue('permissions') as string[]) || []).length} permissão(ões) selecionada(s)`
                          : 'Nenhuma permissão selecionada'}
                      </div>
                    </Form.Item>

                    <Form.Item
                      name="permissions"
                      hidden
                      rules={[{ required: true, message: 'Selecione ao menos uma permissão' }]}
                    >
                      <Select mode="multiple" options={PERMISSION_OPTIONS} />
                    </Form.Item>
                  </Col>

                  <Col xs={24}>
                    <div
                      style={{
                        border: '1px solid #f0f0f0',
                        borderRadius: 12,
                        padding: 12,
                        background: '#fafafa',
                      }}
                    >
                      <Row gutter={[12, 12]}>
                        <Col xs={24} md={createSelectedIsWorker ? 12 : 24}>
                          <Form.Item
                            name="ocultarCargo"
                            label="Ocultar cargo"
                            valuePropName="checked"
                            style={{ marginBottom: 0 }}
                          >
                            <Switch checkedChildren="Sim" unCheckedChildren="Não" />
                          </Form.Item>
                        </Col>

                        {createSelectedIsWorker && (
                          <Col xs={24} md={12}>
                            <Form.Item
                              name="estoqueAvancado"
                              label="Pertence ao Estoque Avançado?"
                              valuePropName="checked"
                              style={{ marginBottom: 0 }}
                            >
                              <Switch checkedChildren="Sim" unCheckedChildren="Não" />
                            </Form.Item>
                          </Col>
                        )}
                      </Row>
                    </div>
                  </Col>

                  {createSelectedIsWorker && (
                    <>
                      <Col xs={24} md={6}>
                        <Form.Item name="vendorCode" label="Cód. fornecedor">
                          <Input />
                        </Form.Item>
                      </Col>

                      <Col xs={24} md={6}>
                        <Form.Item name="serviceAreaCode" label="Cód. área">
                          <Input />
                        </Form.Item>
                      </Col>

                      <Col xs={24} md={6}>
                        <Form.Item name="tipoAtendimento" label="Atendimento">
                          <Select
                            allowClear
                            placeholder="Selecione"
                            options={TIPO_ATENDIMENTO_OPTIONS}
                          />
                        </Form.Item>
                      </Col>

                      <Col xs={24} md={6}>
                        <Form.Item name="serviceAreaName" label="Área">
                          <Input />
                        </Form.Item>
                      </Col>
                    </>
                  )}


                </Row>
              </Card>
            </Col>

            <Col xs={24} xl={11}>
              <Card
                size="small"
                title="Endereço"
                style={{ borderRadius: 14, height: '100%' }}
                styles={{ body: { paddingBottom: 8 } }}
              >
                <Row gutter={[12, 12]}>
                  <Col xs={24} md={9}>
                    <Form.Item name="addressZip" label="CEP">
                      <Input
                        placeholder="00000-000"
                        onBlur={async (e) => {
                          const raw = (e.target.value || '').replace(/\D/g, '');
                          if (!raw) return;

                          try {
                            const resp = await api.get('/users/cep', { params: { cep: raw } });

                            createForm.setFieldsValue({
                              addressStreet: resp.data.addressStreet ?? undefined,
                              addressDistrict: resp.data.addressDistrict ?? undefined,
                              addressCity: resp.data.addressCity ?? undefined,
                              addressState: resp.data.addressState ?? undefined,
                              addressCountry: resp.data.addressCountry ?? 'Brasil',
                              addressZip: resp.data.addressZip ?? e.target.value,
                            });
                          } catch {
                            message.warning('Não foi possível buscar o CEP.');
                          }
                        }}
                      />
                    </Form.Item>
                  </Col>

                  <Col xs={24} md={15} style={{ display: 'flex', alignItems: 'end' }}>
                    <Form.Item label=" " style={{ width: '100%', marginBottom: 24 }}>
                      <Button
                        block
                        icon={<SearchOutlined />}
                        onClick={() => {
                          setGeoForForm('create');
                          setGeoOpen(true);
                          setGeoResults([]);
                          setGeoQuery('');
                        }}
                      >
                        Buscar coordenadas
                      </Button>
                    </Form.Item>
                  </Col>

                  <Col xs={24}>
                    <Form.Item name="addressStreet" label="Logradouro">
                      <Input placeholder="Rua / Avenida" />
                    </Form.Item>
                  </Col>

                  <Col xs={24} md={7}>
                    <Form.Item name="addressNumber" label="Número">
                      <Input />
                    </Form.Item>
                  </Col>

                  <Col xs={24} md={17}>
                    <Form.Item name="addressComplement" label="Complemento">
                      <Input />
                    </Form.Item>
                  </Col>

                  <Col xs={24} md={10}>
                    <Form.Item name="addressDistrict" label="Bairro">
                      <Input />
                    </Form.Item>
                  </Col>

                  <Col xs={24} md={10}>
                    <Form.Item name="addressCity" label="Cidade">
                      <Input />
                    </Form.Item>
                  </Col>

                  <Col xs={24} md={4}>
                    <Form.Item name="addressState" label="UF">
                      <Input placeholder="SP" />
                    </Form.Item>
                  </Col>

                  <Col xs={24} md={12}>
                    <Form.Item name="addressCountry" label="País" initialValue="Brasil">
                      <Input />
                    </Form.Item>
                  </Col>

                  <Col xs={24} md={6}>
                    <Form.Item name="lat" label="Latitude">
                      <InputNumber
                        style={{ width: '100%' }}
                        step={0.000001}
                        placeholder="-23.550520"
                      />
                    </Form.Item>
                  </Col>

                  <Col xs={24} md={6}>
                    <Form.Item name="lng" label="Longitude">
                      <InputNumber
                        style={{ width: '100%' }}
                        step={0.000001}
                        placeholder="-46.633308"
                      />
                    </Form.Item>
                  </Col>
                </Row>
              </Card>
            </Col>
          </Row>
        </Form>
      </Modal>
      )}

      <Modal
        title={`Editar: ${editing?.name || ''}`}
        open={editOpen}
        onCancel={() => {
          setEditOpen(false);
          setEditing(null);
          setEditAvatarFile(null);
        }}
        onOk={() => editForm.submit()}
        destroyOnHidden
        width={isMobile ? '100%' : 1380}
        centered
        style={isMobile ? { top: 0, padding: 0 } : undefined}
        styles={{
          body: {
            paddingTop: 12,
            maxHeight: isMobile ? 'calc(100vh - 110px)' : '80vh',
            overflowY: 'auto',
            overflowX: 'hidden',
          },
        }}
      >
        <Form
          layout="vertical"
          form={editForm}
          onFinish={(v) => {
            const isWorker = isWorkerRoleId(v.roleId);

            const payload: any = {
              name: v.name,
              email: v.email || null,
              sex: v.sex,
              roleId: v.roleId,
              managerId: v.managerId ?? null,
              isActive: v.isActive,
              phone: v.phone ?? null,
              cargoDescritivo: v.cargoDescritivo?.trim() || null,
              ocultarCargo: !!v.ocultarCargo,
              sectors:
                Array.isArray(v.sectors) && v.sectors.length
                  ? v.sectors
                  : DEFAULT_SECTORS,
              permissions:
                Array.isArray(v.permissions) && v.permissions.length
                  ? v.permissions
                  : DEFAULT_PERMISSIONS,

              vendorCode: isWorker ? v.vendorCode ?? null : null,
              serviceAreaCode: isWorker ? v.serviceAreaCode ?? null : null,
              serviceAreaName: isWorker ? v.serviceAreaName ?? null : null,
              tipoAtendimento: isWorker ? v.tipoAtendimento ?? null : null,
              estoqueAvancado: isWorker ? !!v.estoqueAvancado : false,
            };

            updateUser.mutate({ id: editing!.id, payload });
          }}
        >
          <Row gutter={[16, 16]} align="stretch">
            <Col xs={24} xl={13}>
              <Card
                size="small"
                title="Dados do colaborador"
                style={{ borderRadius: 14, height: '100%' }}
                styles={{ body: { paddingBottom: 8 } }}
              >
                <Row gutter={[12, 12]}>
                  <Col xs={24}>
                    <div
                      style={{
                        display: 'flex',
                        gap: 16,
                        alignItems: 'center',
                        padding: 12,
                        border: '1px dashed #d9d9d9',
                        borderRadius: 12,
                        background: '#fafafa',
                      }}
                    >
                      <div
                        style={{
                          width: 88,
                          height: 88,
                          borderRadius: 14,
                          overflow: 'hidden',
                          border: '1px solid #d9d9d9',
                          background: '#fff',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          flexShrink: 0,
                        }}
                      >
                        {editAvatarFile ? (
                          <img
                            src={URL.createObjectURL(editAvatarFile)}
                            alt="preview"
                            style={{ width: '100%', height: '100%', objectFit: 'cover' }}
                          />
                        ) : (
                          <Avatar
                            src={abs(editing?.avatarUrl)}
                            size={88}
                            style={{ borderRadius: 14 }}
                          >
                            {editing?.name?.[0]}
                          </Avatar>
                        )}
                      </div>

                      <div style={{ flex: 1 }}>
                        <div style={{ fontWeight: 600, marginBottom: 4 }}>
                          Foto do colaborador
                        </div>
                        <div style={{ color: '#8c8c8c', fontSize: 13, marginBottom: 10 }}>
                          Atualize a imagem de identificação do colaborador.
                        </div>

                        <Space wrap>
                          <Upload
                            accept="image/*"
                            maxCount={1}
                            beforeUpload={(file) => {
                              setEditAvatarFile(file);
                              return false;
                            }}
                            onRemove={() => setEditAvatarFile(null)}
                            showUploadList={false}
                          >
                            <Button icon={<UploadOutlined />}>Selecionar foto</Button>
                          </Upload>

                          {editAvatarFile && (
                            <Button onClick={() => setEditAvatarFile(null)}>
                              Remover nova foto
                            </Button>
                          )}
                        </Space>
                      </div>
                    </div>
                  </Col>

                  <Col xs={24} md={14}>
                    <Form.Item name="name" label="Nome" rules={[{ required: true, message: 'Informe o nome' }]}>
                      <Input placeholder="Nome do colaborador" />
                    </Form.Item>
                  </Col>

                  <Col xs={24} md={10}>
                    <Form.Item name="phone" label="Telefone">
                      <Input
                        placeholder="(11) 99999-9999"
                        maxLength={15}
                        value={editForm.getFieldValue('phone')}
                        onChange={(e) => {
                          editForm.setFieldValue('phone', formatPhone(e.target.value));
                        }}
                      />
                    </Form.Item>
                  </Col>

                  <Col xs={24} md={14}>
                    <Form.Item
                      name="email"
                      label="E-mail"
                      rules={
                        editSelectedIsWorker
                          ? [{ type: 'email', message: 'E-mail inválido' }]
                          : [{ required: true, type: 'email', message: 'Informe um e-mail válido' }]
                      }
                    >
                      <Input placeholder={editSelectedIsWorker ? 'Opcional para prestador sem login' : 'email@empresa.com'} />
                    </Form.Item>
                  </Col>

                  <Col xs={24} md={10}>
                    <Form.Item name="sex" label="Sexo">
                      <Select
                        allowClear
                        placeholder="Selecione"
                        options={[
                          { value: 'M', label: 'Masculino' },
                          { value: 'F', label: 'Feminino' },
                          { value: 'O', label: 'Outro' },
                        ]}
                      />
                    </Form.Item>
                  </Col>

                  <Col xs={24} md={8}>
                    <Form.Item name="roleId" label="Cargo" rules={[{ required: true, message: 'Selecione o cargo' }]}>
                      <Select
                        allowClear
                        placeholder="Selecione"
                        options={canEditAnyUser ? roleOptions : workerRoleOptions}
                        optionFilterProp="label"
                      />
                    </Form.Item>
                  </Col>

                  <Col xs={24} md={8}>
                    <Form.Item name="cargoDescritivo" label="Cargo descritivo">
                      <Input
                        placeholder="Ex.: Supervisor de Atendimento / Coordenador de Operações"
                        maxLength={150}
                      />
                    </Form.Item>
                  </Col>

                  <Col xs={24} md={8}>
                    <Form.Item name="managerId" label="Gestor">
                      <Select
                        allowClear
                        showSearch
                        placeholder="Selecione o gestor"
                        options={managerOptions}
                        optionFilterProp="label"
                        filterOption={(input, option) =>
                          String(option?.label || '').toLowerCase().includes(input.toLowerCase())
                        }
                      />
                    </Form.Item>
                  </Col>

                  <Col xs={24}>
                    <div
                      style={{
                        border: '1px solid #f0f0f0',
                        borderRadius: 12,
                        padding: 12,
                        background: '#fafafa',
                      }}
                    >
                      <Row gutter={[12, 12]}>
                        <Col xs={24} md={editSelectedIsWorker ? 8 : 12}>
                          <Form.Item
                            name="ocultarCargo"
                            label="Ocultar cargo"
                            valuePropName="checked"
                            style={{ marginBottom: 0 }}
                          >
                            <Switch checkedChildren="Sim" unCheckedChildren="Não" />
                          </Form.Item>
                        </Col>

                        {editSelectedIsWorker && (
                          <Col xs={24} md={8}>
                            <Form.Item
                              name="estoqueAvancado"
                              label="Estoque avançado"
                              valuePropName="checked"
                              style={{ marginBottom: 0 }}
                            >
                              <Switch checkedChildren="Sim" unCheckedChildren="Não" />
                            </Form.Item>
                          </Col>
                        )}

                        <Col xs={24} md={editSelectedIsWorker ? 8 : 12}>
                          <Form.Item
                            name="isActive"
                            label="Usuário ativo"
                            valuePropName="checked"
                            style={{ marginBottom: 0 }}
                          >
                            <Switch checkedChildren="Ativo" unCheckedChildren="Inativo" />
                          </Form.Item>
                        </Col>
                      </Row>
                    </div>
                  </Col>

                  {editSelectedIsWorker && (
                    <>
                      <Col xs={24} md={6}>
                        <Form.Item name="vendorCode" label="Cód. fornecedor">
                          <Input />
                        </Form.Item>
                      </Col>

                      <Col xs={24} md={6}>
                        <Form.Item name="serviceAreaCode" label="Cód. área">
                          <Input />
                        </Form.Item>
                      </Col>

                      <Col xs={24} md={6}>
                        <Form.Item name="tipoAtendimento" label="Atendimento">
                          <Select
                            allowClear
                            placeholder="Selecione"
                            options={TIPO_ATENDIMENTO_OPTIONS}
                          />
                        </Form.Item>
                      </Col>

                      <Col xs={24} md={6}>
                        <Form.Item name="serviceAreaName" label="Área">
                          <Input />
                        </Form.Item>
                      </Col>
                    </>
                  )}

                  <Col xs={24} md={12}>
                    <Form.Item
                      name="sectors"
                      label="Setor"
                      rules={[{ required: true, message: 'Selecione ao menos um setor' }]}
                    >
                      <Select
                        mode="multiple"
                        allowClear
                        showSearch
                        optionFilterProp="label"
                        placeholder="Selecione o(s) setor(es)"
                        options={SECTOR_OPTIONS}
                      />
                    </Form.Item>
                  </Col>

                  <Col xs={24} md={12}>
                    <Form.Item
                      label="Abas / Permissões de acesso"
                      tooltip="Selecione as páginas que esse usuário poderá acessar"
                    >
                      <Button
                        block
                        onClick={() => openPermissionsModal('edit')}
                      >
                        Gerenciar permissões
                      </Button>

                      <div style={{ marginTop: 8, color: '#64748b', fontSize: 13 }}>
                        {((editForm.getFieldValue('permissions') as string[]) || []).length
                          ? `${((editForm.getFieldValue('permissions') as string[]) || []).length} permissão(ões) selecionada(s)`
                          : 'Nenhuma permissão selecionada'}
                      </div>
                    </Form.Item>

                    <Form.Item
                      name="permissions"
                      hidden
                      rules={[{ required: true, message: 'Selecione ao menos uma permissão' }]}
                    >
                      <Select mode="multiple" options={PERMISSION_OPTIONS} />
                    </Form.Item>
                  </Col>
                </Row>
              </Card>
            </Col>

            <Col xs={24} xl={11}>
              <Card
                size="small"
                title="Resumo visual"
                style={{ borderRadius: 14, height: '100%' }}
                styles={{ body: { paddingBottom: 8 } }}
              >
                <div
                  style={{
                    border: '1px solid #f0f0f0',
                    borderRadius: 14,
                    padding: 18,
                    background: 'linear-gradient(180deg, #fafcff 0%, #f5f9ff 100%)',
                    marginBottom: 16,
                  }}
                >
                  <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
                    <Avatar src={editAvatarFile ? URL.createObjectURL(editAvatarFile) : abs(editing?.avatarUrl)} size={68}>
                      {editForm.getFieldValue('name')?.[0] || editing?.name?.[0]}
                    </Avatar>

                    <div style={{ minWidth: 0 }}>
                      <div style={{ fontSize: 18, fontWeight: 700, lineHeight: 1.2 }}>
                        {editForm.getFieldValue('name') || editing?.name || 'Colaborador'}
                      </div>
                      <div style={{ color: '#6b7280', marginTop: 4 }}>
                        {editForm.getFieldValue('cargoDescritivo') ||
                          (canEditAnyUser
                            ? roleOptions.find((r) => r.value === editForm.getFieldValue('roleId'))?.label
                            : workerRoleOptions.find((r) => r.value === editForm.getFieldValue('roleId'))?.label) ||
                          'Cargo não informado'}
                      </div>
                      <Space wrap size={[8, 8]} style={{ marginTop: 10 }}>
                        <Tag color={editForm.getFieldValue('isActive') ? 'green' : 'default'}>
                          {editForm.getFieldValue('isActive') ? 'Ativo' : 'Inativo'}
                        </Tag>
                        {editForm.getFieldValue('ocultarCargo') && <Tag color="gold">Cargo oculto</Tag>}
                        {editForm.getFieldValue('estoqueAvancado') && <Tag color="blue">Estoque avançado</Tag>}
                      </Space>
                    </div>
                  </div>
                </div>

                <div
                  style={{
                    border: '1px solid #f0f0f0',
                    borderRadius: 14,
                    padding: 16,
                    background: '#fff',
                  }}
                >
                  <div style={{ fontWeight: 600, marginBottom: 12 }}>Permissões selecionadas</div>

                  <Space wrap size={[8, 8]}>
                    {((editForm.getFieldValue('permissions') as string[]) || []).length ? (
                      ((editForm.getFieldValue('permissions') as string[]) || []).map((perm) => {
                        const option = PERMISSION_OPTIONS.find((p) => p.value === perm);
                        return (
                          <Tag
                            key={perm}
                            style={{
                              padding: '6px 10px',
                              borderRadius: 999,
                              display: 'inline-flex',
                              alignItems: 'center',
                              gap: 6,
                            }}
                          >
                            {PERMISSION_ICON_MAP[perm] || <AppstoreOutlined />}
                            <span>{option?.label || perm}</span>
                          </Tag>
                        );
                      })
                    ) : (
                      <span style={{ color: '#8c8c8c' }}>Nenhuma permissão selecionada</span>
                    )}
                  </Space>
                </div>
                {canEditAnyUser && editing?.loginEnabled !== false && (
                  <div
                    style={{
                      border: '1px solid #f0f0f0',
                      borderRadius: 14,
                      padding: 16,
                      background: '#fff',
                      marginTop: 16,
                    }}
                  >
                    <div style={{ fontWeight: 600, marginBottom: 12 }}>
                      <LockOutlined /> Alterar senha do usuário
                    </div>

                    <Form
                      form={passwordForm}
                      layout="vertical"
                      onFinish={(values) => {
                        if (!editing?.id) return;

                        Modal.confirm({
                          title: 'Confirmar alteração de senha',
                          content: `Deseja realmente alterar a senha de ${editing.name}?`,
                          okText: 'Sim, alterar',
                          cancelText: 'Cancelar',
                          onOk: () =>
                            changeUserPassword.mutate({
                              id: editing.id,
                              payload: values,
                            }),
                        });
                      }}
                    >
                      <Form.Item
                        name="newPassword"
                        label="Nova senha"
                        rules={[
                          { required: true, message: 'Informe a nova senha' },
                          { min: 6, message: 'A senha deve ter no mínimo 6 caracteres' },
                        ]}
                      >
                        <Input.Password placeholder="Digite a nova senha" />
                      </Form.Item>

                      <Form.Item
                        name="confirmNewPassword"
                        label="Confirmar nova senha"
                        dependencies={['newPassword']}
                        rules={[
                          { required: true, message: 'Confirme a nova senha' },
                          ({ getFieldValue }) => ({
                            validator(_, value) {
                              if (!value || getFieldValue('newPassword') === value) {
                                return Promise.resolve();
                              }
                              return Promise.reject(new Error('As senhas não conferem'));
                            },
                          }),
                        ]}
                      >
                        <Input.Password placeholder="Confirme a nova senha" />
                      </Form.Item>

                      <Button
                        type="primary"
                        danger
                        icon={<LockOutlined />}
                        loading={changeUserPassword.isPending}
                        onClick={() => passwordForm.submit()}
                      >
                        Alterar senha
                      </Button>
                    </Form>
                  </div>
                )}
              </Card>
            </Col>
          </Row>
        </Form>
      </Modal>

      {addrUser && (
        <UserAddressModal
          open={addrOpen}
          userId={addrUser.id}
          initial={{
            addressStreet: addrUser.addressStreet || '',
            addressNumber: addrUser.addressNumber || '',
            addressComplement: addrUser.addressComplement || '',
            addressDistrict: addrUser.addressDistrict || '',
            addressCity: addrUser.addressCity || '',
            addressState: addrUser.addressState || '',
            addressZip: addrUser.addressZip || '',
            addressCountry: addrUser.addressCountry || 'Brasil',
            lat: addrUser.lat ?? null,
            lng: addrUser.lng ?? null,
          }}
          onSaved={(patch) => {
            setAddrUser((prev) => (prev ? { ...prev, ...patch } : prev) as any);
            setViewUser((prev) => (prev ? { ...prev, ...patch } : prev) as any);
          }}
          onClose={async () => {
            setAddrOpen(false);
            setAddrUser(null);
            await qc.invalidateQueries({ queryKey: ['users'] });
          }}
        />
      )}

      <Modal
        title="Buscar coordenadas "
        open={geoOpen}
        onCancel={() => setGeoOpen(false)}
        footer={null}
        destroyOnHidden
        width={isMobile ? '100%' : 900}
        style={isMobile ? { top: 0, padding: 0 } : undefined}
      >
        <Space.Compact style={{ width: '100%', marginBottom: 8 }}>
          <Input
            placeholder="Ex.: Rua XV de Novembro, Curitiba"
            value={geoQuery}
            onChange={(e) => setGeoQuery(e.target.value)}
            onPressEnter={searchGeo}
          />
          <Button type="primary" icon={<SearchOutlined />} loading={geoLoading} onClick={searchGeo}>
            Buscar
          </Button>
        </Space.Compact>

        <List
          bordered
          locale={{ emptyText: 'Nenhum resultado' }}
          dataSource={geoResults}
          renderItem={(item: any) => (
            <List.Item actions={[<Button type="link" onClick={() => applyGeo(item)}>Usar</Button>]}>
              <List.Item.Meta
                title={item.label}
                description={
                  <>
                    <div>
                      <b>lat/lng:</b> {item.lat}, {item.lng}
                    </div>
                    <div>
                      <b>cidade:</b> {item.city || '—'} • <b>UF:</b> {item.uf || '—'}
                    </div>
                  </>
                }
              />
            </List.Item>
          )}
        />
      </Modal>

      {canCreateWorker && (
        <Modal
          title="Cadastrar prestador"
          open={workerOpen}
          onCancel={() => {
            setWorkerOpen(false);
            workerForm.resetFields();
            setWorkerAvatarFile(null);
          }}
          onOk={() => workerForm.submit()}
          destroyOnHidden
          width={isMobile ? '100%' : 1360}
          centered
          style={isMobile ? { top: 0, padding: 0 } : undefined}
          styles={{
            body: {
              paddingTop: 12,
              maxHeight: isMobile ? 'calc(100vh - 110px)' : '78vh',
              overflowY: 'auto',
              overflowX: 'hidden',
            },
          }}
        >
          <Form
            layout="vertical"
            form={workerForm}
            initialValues={{
              sectors: DEFAULT_SECTORS,
              ocultarCargo: false,
              estoqueAvancado: false,
              addressCountry: 'Brasil',
            }}
            onFinish={(v) => {
              const payload = {
                name: v.name,
                phone: v.phone || null,
                roleId: v.roleId,
                managerId: v.managerId ?? null,
                estoqueAvancado: !!v.estoqueAvancado,
                vendorCode: v.vendorCode || null,
                serviceAreaCode: v.serviceAreaCode || null,
                serviceAreaName: v.serviceAreaName || null,
                tipoAtendimento: v.tipoAtendimento || null,
                cargoDescritivo: v.cargoDescritivo?.trim() || null,
                ocultarCargo: !!v.ocultarCargo,
                sectors:
                  Array.isArray(v.sectors) && v.sectors.length
                    ? v.sectors
                    : DEFAULT_SECTORS,
                addressStreet: v.addressStreet,
                addressNumber: v.addressNumber || '',
                addressComplement: v.addressComplement || '',
                addressDistrict: v.addressDistrict || '',
                addressCity: v.addressCity,
                addressState: v.addressState,
                addressZip: v.addressZip || '',
                addressCountry: v.addressCountry || 'Brasil',
                lat: v.lat,
                lng: v.lng,
              };

              createWorker.mutate(payload);
            }}
          >
            <Row gutter={[16, 16]} align="stretch">
              <Col xs={24} xl={13}>
                <Card
                  size="small"
                  title="Dados do prestador"
                  style={{ borderRadius: 14, height: '100%' }}
                  styles={{ body: { paddingBottom: 8 } }}
                >
                  <Row gutter={[12, 12]}>
                    <Col xs={24}>
                      <div
                        style={{
                          display: 'flex',
                          gap: 16,
                          alignItems: 'center',
                          padding: 12,
                          border: '1px dashed #d9d9d9',
                          borderRadius: 12,
                          background: '#fafafa',
                        }}
                      >
                        <Upload
                          accept="image/*"
                          maxCount={1}
                          beforeUpload={(file) => {
                            setWorkerAvatarFile(file);
                            return false;
                          }}
                          onRemove={() => setWorkerAvatarFile(null)}
                          showUploadList={false}
                        >
                          <div
                            style={{
                              width: 88,
                              height: 88,
                              borderRadius: 14,
                              overflow: 'hidden',
                              border: '1px solid #d9d9d9',
                              display: 'flex',
                              alignItems: 'center',
                              justifyContent: 'center',
                              background: '#fff',
                              cursor: 'pointer',
                              flexShrink: 0,
                            }}
                          >
                            {workerAvatarFile ? (
                              <img
                                src={URL.createObjectURL(workerAvatarFile)}
                                alt="preview"
                                style={{ width: '100%', height: '100%', objectFit: 'cover' }}
                              />
                            ) : (
                              <UploadOutlined style={{ fontSize: 24, color: '#8c8c8c' }} />
                            )}
                          </div>
                        </Upload>

                        <div style={{ flex: 1 }}>
                          <div style={{ fontWeight: 600, marginBottom: 4 }}>
                            Foto do prestador
                          </div>
                          <div style={{ color: '#8c8c8c', fontSize: 13, marginBottom: 10 }}>
                            Adicione uma foto para identificação do colaborador.
                          </div>

                          <Space wrap>
                            <Upload
                              accept="image/*"
                              maxCount={1}
                              beforeUpload={(file) => {
                                setWorkerAvatarFile(file);
                                return false;
                              }}
                              onRemove={() => setWorkerAvatarFile(null)}
                              showUploadList={false}
                            >
                              <Button icon={<UploadOutlined />}>Selecionar foto</Button>
                            </Upload>

                            {workerAvatarFile && (
                              <Button onClick={() => setWorkerAvatarFile(null)}>
                                Remover
                              </Button>
                            )}
                          </Space>
                        </div>
                      </div>
                    </Col>

                    <Col xs={24} md={10}>
                      <Form.Item
                        name="roleId"
                        label="Cargo"
                        rules={[{ required: true, message: 'Selecione o cargo do prestador' }]}
                      >
                        <Select
                          placeholder="Selecione"
                          optionFilterProp="label"
                          options={workerRoleOptions}
                        />
                      </Form.Item>
                    </Col>

                    <Col xs={24} md={14}>
                      <Form.Item name="cargoDescritivo" label="Cargo descritivo">
                        <Input
                          placeholder="Ex.: Técnico de Campo / PSO Operacional"
                          maxLength={150}
                        />
                      </Form.Item>
                    </Col>

                    <Col xs={24} md={14}>
                      <Form.Item name="name" label="Nome" rules={[{ required: true, message: 'Informe o nome' }]}>
                        <Input placeholder="Nome do prestador" />
                      </Form.Item>
                    </Col>

                    <Col xs={24} md={10}>
                      <Form.Item name="phone" label="Telefone">
                        <Input
                          placeholder="(11) 99999-9999"
                          maxLength={15}
                          value={workerForm.getFieldValue('phone')}
                          onChange={(e) => {
                            workerForm.setFieldValue('phone', formatPhone(e.target.value));
                          }}
                        />
                      </Form.Item>
                    </Col>

                    <Col xs={24} md={12}>
                      <Form.Item name="managerId" label="Gestor (opcional)">
                        <Select
                          allowClear
                          showSearch
                          placeholder="Selecione o gestor"
                          options={managerOptions}
                          optionFilterProp="label"
                          filterOption={(input, option) =>
                            String(option?.label || '').toLowerCase().includes(input.toLowerCase())
                          }
                        />
                      </Form.Item>
                    </Col>

                    <Col xs={24} md={12}>
                      <Form.Item
                        name="sectors"
                        label="Setor"
                        rules={[{ required: true, message: 'Selecione ao menos um setor' }]}
                      >
                        <Select
                          mode="multiple"
                          allowClear
                          showSearch
                          optionFilterProp="label"
                          placeholder="Selecione o(s) setor(es)"
                          options={SECTOR_OPTIONS}
                        />
                      </Form.Item>
                    </Col>

                    <Col xs={24}>
                      <div
                        style={{
                          border: '1px solid #f0f0f0',
                          borderRadius: 12,
                          padding: 12,
                          background: '#fafafa',
                        }}
                      >
                        <Row gutter={[12, 12]}>
                          <Col xs={24} md={12}>
                            <Form.Item
                              name="ocultarCargo"
                              label="Ocultar cargo"
                              valuePropName="checked"
                              style={{ marginBottom: 0 }}
                            >
                              <Switch checkedChildren="Sim" unCheckedChildren="Não" />
                            </Form.Item>
                          </Col>

                          <Col xs={24} md={12}>
                            <Form.Item
                              name="estoqueAvancado"
                              label="Pertence ao Estoque Avançado?"
                              valuePropName="checked"
                              style={{ marginBottom: 0 }}
                            >
                              <Switch checkedChildren="Sim" unCheckedChildren="Não" />
                            </Form.Item>
                          </Col>
                        </Row>
                      </div>
                    </Col>

                    <Col xs={24} md={6}>
                      <Form.Item name="vendorCode" label="Cód. fornecedor">
                        <Input />
                      </Form.Item>
                    </Col>

                    <Col xs={24} md={6}>
                      <Form.Item name="serviceAreaCode" label="Cód. área">
                        <Input />
                      </Form.Item>
                    </Col>

                    <Col xs={24} md={6}>
                      <Form.Item name="tipoAtendimento" label="Atendimento">
                        <Select
                          allowClear
                          placeholder="Selecione"
                          options={TIPO_ATENDIMENTO_OPTIONS}
                        />
                      </Form.Item>
                    </Col>

                    <Col xs={24} md={6}>
                      <Form.Item name="serviceAreaName" label="Área">
                        <Input />
                      </Form.Item>
                    </Col>
                  </Row>
                </Card>
              </Col>

              <Col xs={24} xl={11}>
                <Card
                  size="small"
                  title="Endereço"
                  style={{ borderRadius: 14, height: '100%' }}
                  styles={{ body: { paddingBottom: 8 } }}
                >
                  <Row gutter={[12, 12]}>
                    <Col xs={24} md={9}>
                      <Form.Item name="addressZip" label="CEP">
                        <Input
                          placeholder="00000-000"
                          onBlur={async (e) => {
                            const raw = (e.target.value || '').replace(/\D/g, '');
                            if (!raw) return;

                            try {
                              const resp = await api.get('/users/cep', { params: { cep: raw } });

                              workerForm.setFieldsValue({
                                addressStreet: resp.data.addressStreet ?? undefined,
                                addressDistrict: resp.data.addressDistrict ?? undefined,
                                addressCity: resp.data.addressCity ?? undefined,
                                addressState: resp.data.addressState ?? undefined,
                                addressCountry: resp.data.addressCountry ?? 'Brasil',
                                addressZip: resp.data.addressZip ?? e.target.value,
                              });
                            } catch {
                              message.warning('Não foi possível buscar o CEP.');
                            }
                          }}
                        />
                      </Form.Item>
                    </Col>

                    <Col xs={24} md={15} style={{ display: 'flex', alignItems: 'end' }}>
                      <Form.Item label=" " style={{ width: '100%', marginBottom: 24 }}>
                        <Button
                          block
                          icon={<SearchOutlined />}
                          onClick={() => {
                            setGeoForForm('worker');
                            setGeoOpen(true);
                            setGeoResults([]);
                            setGeoQuery('');
                          }}
                        >
                          Buscar coordenadas
                        </Button>
                      </Form.Item>
                    </Col>

                    <Col xs={24}>
                      <Form.Item
                        name="addressStreet"
                        label="Logradouro"
                        rules={[{ required: true, message: 'Informe o logradouro' }]}
                      >
                        <Input placeholder="Rua / Avenida" />
                      </Form.Item>
                    </Col>

                    <Col xs={24} md={7}>
                      <Form.Item name="addressNumber" label="Número">
                        <Input />
                      </Form.Item>
                    </Col>

                    <Col xs={24} md={17}>
                      <Form.Item name="addressComplement" label="Complemento">
                        <Input />
                      </Form.Item>
                    </Col>

                    <Col xs={24} md={10}>
                      <Form.Item name="addressDistrict" label="Bairro">
                        <Input />
                      </Form.Item>
                    </Col>

                    <Col xs={24} md={10}>
                      <Form.Item
                        name="addressCity"
                        label="Cidade"
                        rules={[{ required: true, message: 'Informe a cidade' }]}
                      >
                        <Input />
                      </Form.Item>
                    </Col>

                    <Col xs={24} md={4}>
                      <Form.Item
                        name="addressState"
                        label="UF"
                        rules={[{ required: true, message: 'Informe a UF' }]}
                      >
                        <Input placeholder="SP" />
                      </Form.Item>
                    </Col>

                    <Col xs={24} md={12}>
                      <Form.Item name="addressCountry" label="País" initialValue="Brasil">
                        <Input />
                      </Form.Item>
                    </Col>

                    <Col xs={24} md={6}>
                      <Form.Item
                        name="lat"
                        label="Latitude"
                        rules={[{ required: true, message: 'Informe a latitude' }]}
                      >
                        <InputNumber
                          style={{ width: '100%' }}
                          step={0.000001}
                          placeholder="-23.550520"
                        />
                      </Form.Item>
                    </Col>

                    <Col xs={24} md={6}>
                      <Form.Item
                        name="lng"
                        label="Longitude"
                        rules={[{ required: true, message: 'Informe a longitude' }]}
                      >
                        <InputNumber
                          style={{ width: '100%' }}
                          step={0.000001}
                          placeholder="-46.633308"
                        />
                      </Form.Item>
                    </Col>
                  </Row>
                </Card>
              </Col>
            </Row>
          </Form>
        </Modal>
      )}

      <Modal
        title={
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <ApartmentOutlined />
            <span>Estrutura — {viewUser?.name || ''}</span>
          </div>
        }
        open={structureOpen}
        onCancel={() => {
          setStructureOpen(false);
          setStructure(null);
        }}
        footer={null}
        width={isMobile ? '100%' : 980}
        style={isMobile ? { top: 0, padding: 0 } : undefined}
        styles={{ body: { background: '#fafafa'} }}
        destroyOnHidden
      >
        {loadingStructure ? (
          <div style={{ textAlign: 'center', padding: 24 }}>
            <Spin />
          </div>
        ) : structure ? (
          <div style={{ padding: 8 }}>
            <div
              style={{
                position: 'relative',
                padding: 16,
                borderRadius: 12,
                background: '#fff',
                border: '1px solid #f0f0f0',
              }}
            >
              <div style={{ display: 'flex', justifyContent: 'center' }}>
                {structure.acima && structure.acima.length > 0 ? (
                  <OrgCard title="Superior" person={structure.acima[0]} badge="ACIMA" />
                ) : (
                  <div style={{ textAlign: 'center', color: '#94a3b8', padding: 10 }}>— sem superior —</div>
                )}
              </div>

              <div style={{ display: 'flex', justifyContent: 'center' }}>
                <div style={{ width: 2, height: 22, background: '#e5e7eb', margin: '10px 0' }} />
              </div>

              <div style={{ display: 'flex', justifyContent: 'center' }}>
                {structure.atual ? (
                  <OrgCard title="Colaborador" person={structure.atual} highlight badge="ATUAL" />
                ) : null}
              </div>

              <div style={{ display: 'flex', justifyContent: 'center' }}>
                <div style={{ width: 2, height: 22, background: '#e5e7eb', margin: '10px 0' }} />
              </div>

              <div style={{ marginTop: 8 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 10 }}>
                  <Title level={5} style={{ margin: 0 }}>
                    Subordinados
                  </Title>
                  <Tag color="blue">{(structure.abaixo || []).length}</Tag>
                </div>

                {structure.abaixo && structure.abaixo.length > 0 ? (
                  <div
                    style={{
                      display: 'grid',
                      gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))',
                      gap: 12,
                    }}
                  >
                    {structure.abaixo.map((p: any) => (
                      <OrgMiniCard key={p.id || p.email || p.nome} person={p} />
                    ))}
                  </div>
                ) : (
                  <div style={{ color: '#94a3b8' }}>— nenhum subordinado —</div>
                )}
              </div>
            </div>
          </div>
        ) : (
          <Text type="secondary">Selecione um colaborador</Text>
        )}
      </Modal>

      <Modal
        title="Solicitações de cadastro"
        open={requestsOpen}
        onCancel={() => setRequestsOpen(false)}
        footer={null}
        destroyOnHidden
        width={isMobile ? '100%' : 1100}
        style={isMobile ? { top: 0, padding: 0 } : undefined}
      >
        <div style={{ display: 'grid', gap: 12 }}>
          <Row gutter={[12, 12]}>
            <Col xs={24} md={12}>
              <Input
                allowClear
                prefix={<SearchOutlined />}
                placeholder="Buscar por nome ou e-mail"
                value={requestSearch}
                onChange={(e) => setRequestSearch(e.target.value)}
              />
            </Col>

            <Col xs={24} md={6}>
              <Select
                value={requestStatusFilter}
                onChange={(v) => setRequestStatusFilter(v)}
                style={{ width: '100%' }}
                options={[
                  { value: 'ALL', label: 'Todos os status' },
                  { value: 'PENDING', label: 'Pendentes' },
                  { value: 'APPROVED', label: 'Aprovadas' },
                  { value: 'REJECTED', label: 'Reprovadas' },
                ]}
              />
            </Col>

            <Col xs={24} md={6}>
              <Button block icon={<ReloadOutlined />} loading={requestsFetching} onClick={() => refetchRequests()}>
                Atualizar
              </Button>
            </Col>
          </Row>

          {requestsLoading ? (
            <div style={{ textAlign: 'center', padding: 24 }}>
              <Spin />
            </div>
          ) : !filteredRequests.length ? (
            <Empty description="Nenhuma solicitação encontrada" />
          ) : (
            <List
              dataSource={filteredRequests}
              rowKey={(r) => r.id}
              renderItem={(req) => (
                <List.Item style={{ paddingInline: 0 }}>
                  <Card
                    style={{ width: '100%' }}
                    styles={{
                      body: {
                        padding: 16,
                      },
                    }}
                  >
                    <Row gutter={[16, 16]}>
                      <Col xs={24} lg={14}>
                        <div style={{ display: 'flex', gap: 12, alignItems: 'flex-start' }}>
                          <Avatar src={abs(req.avatarUrl)} size={56}>
                            {initial(req.fullName)}
                          </Avatar>

                          <div style={{ flex: 1, minWidth: 0 }}>
                            <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', alignItems: 'center' }}>
                              <Title level={5} style={{ margin: 0 }}>
                                {req.fullName}
                              </Title>
                              {requestStatusTag(req.status)}
                            </div>

                            <div style={{ color: '#64748b', marginTop: 4 }}>{req.email}</div>

                            <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginTop: 8 }}>
                              <Tag>
                                {getDisplayRoleLabel(req.role?.name, req.cargoDescritivo, req.ocultarCargo)}
                              </Tag>
                              <Tag>{req.manager?.name ? `Gestor: ${req.manager.name}` : 'Sem gestor'}</Tag>

                              {Array.isArray(req.sectors) && req.sectors.length > 0 && (
                                <Tag color="purple">
                                  Setor: {req.sectors.map(getSectorLabel).join(', ')}
                                </Tag>
                              )}

                              {req.phone ? <Tag>{req.phone}</Tag> : null}
                            </div>

                            {Array.isArray(req.permissions) && req.permissions.length > 0 && (
                              <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginTop: 8 }}>
                                {req.permissions.map((permission) => (
                                  <Tag key={permission} color="blue">
                                    {getPermissionLabel(permission)}
                                  </Tag>
                                ))}
                              </div>
                            )}

                            <Descriptions
                              size="small"
                              column={isMobile ? 1 : 2}
                              style={{ marginTop: 12 }}
                              items={[
                                {
                                  key: 'sexo',
                                  label: 'Sexo',
                                  children:
                                    req.sex === 'M'
                                      ? 'Masculino'
                                      : req.sex === 'F'
                                      ? 'Feminino'
                                      : req.sex === 'O'
                                      ? 'Outro'
                                      : '—',
                                },
                                {
                                  key: 'dataSolicitacao',
                                  label: 'Solicitado em',
                                  children: req.createdAt
                                    ? new Date(req.createdAt).toLocaleString('pt-BR')
                                    : '—',
                                },
                                {
                                  key: 'cargoDescritivo',
                                  label: 'Cargo descritivo',
                                  children: req.ocultarCargo ? 'Oculto' : req.cargoDescritivo || '—',
                                },
                                {
                                  key: 'aprovadoPor',
                                  label: 'Aprovado por',
                                  children: req.approvedBy?.name || '—',
                                },
                              ]}
                            />

                            {req.reviewNotes ? (
                              <>
                                <Divider style={{ margin: '12px 0' }} />
                                <Text type="secondary">Observação:</Text>
                                <div style={{ marginTop: 4 }}>{req.reviewNotes}</div>
                              </>
                            ) : null}
                          </div>
                        </div>
                      </Col>

                      <Col xs={24} lg={10}>
                        <div
                          style={{
                            height: '100%',
                            display: 'flex',
                            flexDirection: 'column',
                            justifyContent: 'space-between',
                            gap: 12,
                          }}
                        >
                          <Card size="small" title="Ações" styles={{ body: { padding: 12 } }}>
                            {req.status !== 'PENDING' ? (
                              <Text type="secondary">Solicitação já analisada.</Text>
                            ) : (
                              <Space wrap>
                                <Popconfirm
                                  title="Aprovar solicitação?"
                                  description="Isso criará o usuário definitivo com permissões e setor padrão."
                                  onConfirm={() => approveRequest.mutate(req.id)}
                                  okText="Aprovar"
                                  cancelText="Cancelar"
                                >
                                  <Button
                                    type="primary"
                                    icon={<CheckOutlined />}
                                    loading={approveRequest.isPending}
                                  >
                                    Aprovar
                                  </Button>
                                </Popconfirm>

                                <Button
                                  icon={<EditOutlined />}
                                  onClick={() => openEditApproveModal(req)}
                                >
                                  Editar e aprovar
                                </Button>

                                <Popconfirm
                                  title="Reprovar solicitação?"
                                  description="Essa ação marcará a solicitação como recusada."
                                  onConfirm={() =>
                                    rejectRequest.mutate({
                                      id: req.id,
                                      reviewNotes: 'Solicitação reprovada pelo gestor',
                                    })
                                  }
                                  okText="Reprovar"
                                  cancelText="Cancelar"
                                >
                                  <Button
                                    danger
                                    icon={<CloseOutlined />}
                                    loading={rejectRequest.isPending}
                                  >
                                    Reprovar
                                  </Button>
                                </Popconfirm>
                              </Space>
                            )}
                          </Card>
                        </div>
                      </Col>
                    </Row>
                  </Card>
                </List.Item>
              )}
            />
          )}
        </div>
      </Modal>

      <Modal
        title={`Editar e aprovar${editingRequest ? ` — ${editingRequest.fullName}` : ''}`}
        open={editApproveOpen}
        onCancel={() => {
          setEditApproveOpen(false);
          setEditingRequest(null);
          editApproveForm.resetFields();
        }}
        onOk={() => editApproveForm.submit()}
        destroyOnHidden
        width={isMobile ? '100%' : 920}
        style={isMobile ? { top: 0, padding: 0 } : undefined}
      >
        <Form
          layout="vertical"
          form={editApproveForm}
          initialValues={{
            permissions: DEFAULT_PERMISSIONS,
            sectors: DEFAULT_SECTORS,
            ocultarCargo: false,
          }}
          onFinish={(v) => {
            if (!editingRequest) return;

            const payload = {
              fullName: v.fullName,
              email: v.email,
              sex: v.sex || null,
              roleId: v.roleId,
              managerId: v.managerId ?? null,
              phone: v.phone || null,
              reviewNotes: v.reviewNotes || null,
              cargoDescritivo: v.cargoDescritivo?.trim() || null,
              ocultarCargo: !!v.ocultarCargo,
              sectors:
                Array.isArray(v.sectors) && v.sectors.length
                  ? v.sectors
                  : DEFAULT_SECTORS,
              permissions:
                Array.isArray(v.permissions) && v.permissions.length
                  ? v.permissions
                  : DEFAULT_PERMISSIONS,
            };

            approveRequestWithEdit.mutate({ id: editingRequest.id, payload });
          }}
        >
          <Row gutter={[12, 12]}>
            <Col xs={24}>
              <Form.Item name="fullName" label="Nome completo" rules={[{ required: true, message: 'Informe o nome' }]}>
                <Input />
              </Form.Item>
            </Col>

            <Col xs={24} md={12}>
              <Form.Item
                name="email"
                label="E-mail"
                rules={[
                  { required: true, message: 'Informe o e-mail' },
                  { type: 'email', message: 'E-mail inválido' },
                ]}
              >
                <Input />
              </Form.Item>
            </Col>

            <Col xs={24} md={12}>
                <Form.Item name="phone" label="Telefone">
                  <Input
                    placeholder="(11) 99999-9999"
                    maxLength={15}
                    value={workerForm.getFieldValue('phone')}
                    onChange={(e) => {
                      workerForm.setFieldValue('phone', formatPhone(e.target.value));
                    }}
                  />
                </Form.Item>
            </Col>

            <Col xs={24} md={6}>
              <Form.Item name="sex" label="Sexo">
                <Select
                  allowClear
                  options={[
                    { value: 'M', label: 'Masculino' },
                    { value: 'F', label: 'Feminino' },
                    { value: 'O', label: 'Outro' },
                  ]}
                />
              </Form.Item>
            </Col>

            <Col xs={24} md={9}>
              <Form.Item name="roleId" label="Cargo" rules={[{ required: true, message: 'Selecione o cargo' }]}>
                <Select options={roleOptions} optionFilterProp="label" showSearch />
              </Form.Item>
            </Col>

            <Col xs={24} md={9}>
              <Form.Item name="managerId" label="Gestor">
                <Select
                  allowClear
                  showSearch
                  placeholder="Selecione o gestor"
                  options={managerOptions}
                  optionFilterProp="label"
                  filterOption={(input, option) =>
                    String(option?.label || '').toLowerCase().includes(input.toLowerCase())
                  }
                />
              </Form.Item>
            </Col>

            <Col xs={24} md={12}>
              <Form.Item name="cargoDescritivo" label="Cargo descritivo">
                <Input placeholder="Ex.: Supervisor de Atendimento / Coordenador de Dados" maxLength={150} />
              </Form.Item>
            </Col>

            <Col xs={24} md={12}>
              <Form.Item name="ocultarCargo" label="Ocultar cargo" valuePropName="checked">
                <Switch checkedChildren="Sim" unCheckedChildren="Não" />
              </Form.Item>
            </Col>

            <Col xs={24}>
              <Form.Item
                name="sectors"
                label="Setor"
                rules={[{ required: true, message: 'Selecione ao menos um setor' }]}
              >
                <Select
                  mode="multiple"
                  allowClear
                  showSearch
                  optionFilterProp="label"
                  placeholder="Selecione o(s) setor(es) do usuário"
                  options={SECTOR_OPTIONS}
                />
              </Form.Item>
            </Col>

            <Col xs={24}>
              <Form.Item
                label="Abas / Permissões de acesso"
                tooltip="Escolha exatamente quais abas esse usuário poderá acessar após a aprovação"
              >
                <Button
                  block
                  onClick={() => openPermissionsModal('approve')}
                >
                  Gerenciar permissões
                </Button>

                <div style={{ marginTop: 8, color: '#64748b', fontSize: 13 }}>
                  {((editApproveForm.getFieldValue('permissions') as string[]) || []).length
                    ? `${((editApproveForm.getFieldValue('permissions') as string[]) || []).length} permissão(ões) selecionada(s)`
                    : 'Nenhuma permissão selecionada'}
                </div>
              </Form.Item>

              <Form.Item
                name="permissions"
                hidden
                rules={[{ required: true, message: 'Selecione ao menos uma permissão' }]}
              >
                <Select mode="multiple" options={PERMISSION_OPTIONS} />
              </Form.Item>
            </Col>

            <Col xs={24}>
              <Form.Item name="reviewNotes" label="Observação do aprovador">
                <Input.TextArea rows={4} placeholder="Ex.: aprovado com ajuste de cargo / gestor / permissões / setor" />
              </Form.Item>
            </Col>
          </Row>
        </Form>
      </Modal>

      <Modal
        title="Gerenciar permissões"
        open={permissionsOpen}
        onCancel={() => setPermissionsOpen(false)}
        width="60vw"
        centered
        zIndex={3000}
        styles={{
          mask: { zIndex: 2999 },
          body: {
            overflow: 'hidden',
            paddingTop: 10,
          },
        }}
        footer={[
          <Button key="clear" danger onClick={() => setPermissionsDraft(['DASHBOARD_VIEW'])}>
            Limpar permissões
          </Button>,
          <Button key="cancel" onClick={() => setPermissionsOpen(false)}>
            Cancelar
          </Button>,
          <Button
            key="ok"
            type="primary"
            onClick={() => {
              const nextPermissions = permissionsDraft.length ? permissionsDraft : ['DASHBOARD_VIEW'];
              getPermissionForm().setFieldValue('permissions', nextPermissions);
              getPermissionForm().validateFields(['permissions']).catch(() => undefined);
              setPermissionsOpen(false);
            }}
          >
            Aplicar permissões
          </Button>,
        ]}
      >
        <div
          style={{
            marginBottom: 14,
            padding: '10px 12px',
            borderRadius: 12,
            background: '#f8fafc',
            border: '1px solid #e5e7eb',
            color: '#475569',
            fontSize: 13,
          }}
        >
          {permissionsDraft.length} permissão(ões) selecionada(s). Clique no card inteiro para selecionar ou remover.
        </div>

        <Row gutter={[14, 14]} style={{ margin: 0 }}>
          {PERMISSION_OPTIONS.map((p) => {
            const selected = permissionsDraft.includes(p.value);

            const togglePermission = () => {
              setPermissionsDraft((current) =>
                current.includes(p.value)
                  ? current.filter((v) => v !== p.value)
                  : [...current, p.value]
              );
            };

            return (
              <Col xs={24} sm={12} md={8} lg={6} xl={6} key={p.value}>
                <Card
                  hoverable
                  size="small"
                  onClick={togglePermission}
                  styles={{
                    body: {
                      padding: 12,
                      cursor: 'pointer',
                      minHeight: 52,
                      display: 'flex',
                      alignItems: 'center',
                    },
                  }}
                  style={{
                    borderRadius: 12,
                    cursor: 'pointer',
                    transition: 'all 0.2s ease',
                    border: selected ? '2px solid #1677ff' : '1px solid #e5e7eb',
                    background: selected ? '#eff6ff' : '#fff',
                    boxShadow: selected ? '0 6px 16px rgba(22,119,255,0.12)' : undefined,
                  }}
                >
                  <Space align="center">
                    <Checkbox
                      checked={selected}
                      onClick={(event) => event.stopPropagation()}
                      onChange={togglePermission}
                    />

                    <span
                      style={{
                        fontSize: 14,
                        display: 'flex',
                        alignItems: 'center',
                        gap: 8,
                        color: selected ? '#1d4ed8' : '#0f172a',
                        fontWeight: selected ? 600 : 400,
                      }}
                    >
                      {PERMISSION_ICON_MAP[p.value] || <AppstoreOutlined />}
                      {p.label}
                    </span>
                  </Space>
                </Card>
              </Col>
            );
          })}
        </Row>
      </Modal>
    </div>
  );
}